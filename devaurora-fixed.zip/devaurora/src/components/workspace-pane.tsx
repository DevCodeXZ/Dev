import { useMemo } from "react";
import { File, Folder, FolderOpen, X } from "lucide-react";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/lib/store";
import { baseName, isDir, joinPath, listDir, readFile, writeFile } from "@/lib/vfs";

function Tree({
  path,
  depth,
  openPath,
  onOpen,
}: {
  path: string;
  depth: number;
  openPath: string | null;
  onOpen: (p: string) => void;
}) {
  const vfs = useAppStore((s) => s.vfs);
  const names = useMemo(() => {
    try {
      return listDir(vfs, path);
    } catch {
      return [];
    }
  }, [vfs, path]);

  return (
    <ul className="text-sm">
      {names.map((name) => {
        const child = joinPath(path, name);
        const dir = isDir(vfs, child);
        const active = openPath === child;
        return (
          <li key={child}>
            <button
              type="button"
              onClick={() => onOpen(child)}
              className={cn(
                "flex h-8 w-full items-center gap-1.5 rounded-md px-1.5 text-left hover:bg-hover",
                active && "bg-elevated",
              )}
              style={{ paddingLeft: 8 + depth * 12 }}
            >
              {dir ? (
                <FolderOpen className="size-3.5 shrink-0 text-dim" />
              ) : (
                <File className="size-3.5 shrink-0 text-dim" />
              )}
              <span className="truncate">{name}</span>
            </button>
            {dir ? <Tree path={child} depth={depth + 1} openPath={openPath} onOpen={onOpen} /> : null}
          </li>
        );
      })}
    </ul>
  );
}

export function WorkspacePane({ onClose }: { onClose: () => void }) {
  const vfs = useAppStore((s) => s.vfs);
  const openFilePath = useAppStore((s) => s.openFilePath);
  const setOpenFilePath = useAppStore((s) => s.setOpenFilePath);
  const setVfs = useAppStore((s) => s.setVfs);

  const content = useMemo(() => {
    if (!openFilePath) return "";
    try {
      return readFile(vfs, openFilePath);
    } catch {
      return "";
    }
  }, [vfs, openFilePath]);

  const onOpen = (p: string) => {
    if (isDir(useAppStore.getState().vfs, p)) return;
    setOpenFilePath(p);
  };

  return (
    <div className="flex h-full min-h-0 bg-main">
      <div className="flex w-[200px] shrink-0 flex-col border-r border-border">
        <div className="flex h-9 items-center justify-between px-3 text-xs font-medium text-muted">
          <span className="inline-flex items-center gap-1">
            <Folder className="size-3.5" />
            Workspace
          </span>
          <button
            type="button"
            className="flex size-8 items-center justify-center rounded-md text-dim hover:bg-hover hover:text-fg md:hidden"
            onClick={onClose}
            aria-label="Cerrar archivos"
          >
            <X className="size-3.5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-auto px-1 pb-2">
          <Tree path="/workspace" depth={0} openPath={openFilePath} onOpen={onOpen} />
        </div>
      </div>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex h-9 items-center justify-between border-b border-border px-3">
          <span className="truncate font-mono text-xs text-muted">
            {openFilePath ? openFilePath.replace(/^\/workspace\//, "") : "Sin archivo"}
          </span>
          <button
            type="button"
            className="hidden size-8 items-center justify-center rounded-md text-dim hover:bg-hover hover:text-fg md:flex"
            onClick={onClose}
            aria-label="Cerrar archivos"
          >
            <X className="size-3.5" />
          </button>
        </div>
        {openFilePath ? (
          <textarea
            key={openFilePath}
            defaultValue={content}
            onBlur={(e) => {
              setVfs(writeFile(vfs, openFilePath, e.target.value));
            }}
            spellCheck={false}
            className="min-h-0 flex-1 bg-code p-3 font-mono text-[13px] leading-relaxed text-fg outline-none"
            aria-label={baseName(openFilePath)}
          />
        ) : (
          <div className="flex flex-1 items-center justify-center text-sm text-dim">
            Selecciona un archivo
          </div>
        )}
      </div>
    </div>
  );
}
