import { useEffect, useRef, useState } from "react";
import { ArrowUp, Mic, Paperclip, Plus, Square, Terminal, X } from "lucide-react";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/lib/store";
import { resolvePath, writeFile } from "@/lib/vfs";

type SpeechRec = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  onresult: ((ev: { results: { [i: number]: { [j: number]: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
};

export function Composer({
  onSend,
  streaming,
  onStop,
  disabled,
}: {
  onSend: (text: string, attachments?: { name: string; path: string }[]) => void;
  streaming: boolean;
  onStop: () => void;
  disabled?: boolean;
}) {
  const [value, setValue] = useState("");
  const [menu, setMenu] = useState(false);
  const [listening, setListening] = useState(false);
  const [pending, setPending] = useState<{ name: string; path: string }[]>([]);
  const ta = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<SpeechRec | null>(null);
  const cwd = useAppStore((s) => s.cwd);
  const setTerminalOpen = useAppStore((s) => s.setTerminalOpen);

  useEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [value]);

  const submit = () => {
    if (streaming) {
      onStop();
      return;
    }
    const text = value.trim();
    if (!text && !pending.length) return;
    onSend(text, pending.length ? pending : undefined);
    setValue("");
    setPending([]);
    if (ta.current) ta.current.style.height = "auto";
  };

  const attachFiles = async (files: FileList | File[]) => {
    const store = useAppStore.getState();
    const added: { name: string; path: string }[] = [];
    let map = store.vfs;
    for (const file of Array.from(files)) {
      const text = await file.text();
      const path = resolvePath(cwd, file.name);
      map = writeFile(map, path, text);
      added.push({ name: file.name, path });
    }
    store.setVfs(map);
    store.setWorkspaceOpen(true);
    if (added[0]) store.setOpenFilePath(added[0].path);
    setPending((p) => [...p, ...added]);
  };

  const toggleMic = () => {
    const SR = (window as unknown as {
      SpeechRecognition?: new () => SpeechRec;
      webkitSpeechRecognition?: new () => SpeechRec;
    }).SpeechRecognition ??
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRec }).webkitSpeechRecognition;
    if (!SR) return;
    if (listening) {
      recRef.current?.stop();
      setListening(false);
      return;
    }
    const rec = new SR();
    rec.lang = "es-ES";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (ev) => {
      const t = ev.results[0]?.[0]?.transcript ?? "";
      if (t) setValue((v) => (v ? v + " " + t : t));
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    rec.start();
    setListening(true);
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-3 pb-3 md:px-4">
      {pending.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-2">
          {pending.map((f) => (
            <span
              key={f.path}
              className="inline-flex items-center gap-1 rounded-full bg-chip px-2 py-1 text-xs text-muted"
            >
              {f.name}
              <button
                type="button"
                className="size-5 text-dim hover:text-fg"
                onClick={() => setPending((p) => p.filter((x) => x.path !== f.path))}
                aria-label="Quitar archivo"
              >
                <X className="size-3" />
              </button>
            </span>
          ))}
        </div>
      )}
      <div
        className={cn(
          "relative rounded-composer bg-composer shadow-composer",
          "focus-within:ring-1 focus-within:ring-border",
        )}
      >
        {menu && (
          <div className="absolute bottom-full left-2 mb-2 w-52 overflow-hidden rounded-xl border border-border bg-elevated py-1 shadow-lg">
            <button
              type="button"
              className="flex h-10 w-full items-center gap-2 px-3 text-sm hover:bg-hover"
              onClick={() => {
                fileRef.current?.click();
                setMenu(false);
              }}
            >
              <Paperclip className="size-4" />
              Subir archivo
            </button>
            <button
              type="button"
              className="flex h-10 w-full items-center gap-2 px-3 text-sm hover:bg-hover"
              onClick={() => {
                setTerminalOpen(true);
                setMenu(false);
              }}
            >
              <Terminal className="size-4" />
              Abrir terminal
            </button>
          </div>
        )}
        <div className="flex items-end gap-1 p-2">
          <button
            type="button"
            className="mb-0.5 flex size-10 items-center justify-center rounded-full text-muted hover:bg-hover hover:text-fg"
            onClick={() => setMenu((v) => !v)}
            aria-label="Añadir"
          >
            <Plus className="size-5" />
          </button>
          <textarea
            ref={ta}
            rows={1}
            value={value}
            disabled={disabled}
            placeholder="Pregunta lo que sea"
            className="max-h-[200px] min-h-10 flex-1 bg-transparent py-2.5 text-[15px] leading-6 text-fg outline-none placeholder:text-dim"
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit();
              }
            }}
          />
          <button
            type="button"
            className={cn(
              "mb-0.5 flex size-10 items-center justify-center rounded-full text-muted hover:bg-hover hover:text-fg",
              listening && "text-accent",
            )}
            onClick={toggleMic}
            aria-label="Voz"
          >
            <Mic className="size-5" />
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={!streaming && !value.trim() && !pending.length}
            className={cn(
              "mb-0.5 flex size-10 items-center justify-center rounded-full transition-opacity",
              streaming || value.trim() || pending.length
                ? "bg-send text-send-fg"
                : "bg-send/30 text-send-fg/50",
            )}
            aria-label={streaming ? "Detener" : "Enviar"}
          >
            {streaming ? <Square className="size-3.5 fill-current" /> : <ArrowUp className="size-5" />}
          </button>
        </div>
        <input
          ref={fileRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) void attachFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>
      <p className="mt-2 text-center text-[11px] text-dim">
        DevAurora Code puede cometer errores. Verifica el código y la información importante.
      </p>
    </div>
  );
}
