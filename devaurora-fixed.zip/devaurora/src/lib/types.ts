export type Role = "user" | "assistant" | "system" | "tool";

export type ToolCall = {
  id: string;
  name: string;
  arguments: string;
};

export type Attachment = {
  name: string;
  path: string;
};

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  reasoning?: string;
  toolCalls?: ToolCall[];
  toolCallId?: string;
  attachments?: Attachment[];
  createdAt: number;
};

export type Chat = {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
};

export type VfsEntry = {
  type: "file" | "dir";
  content?: string;
  updatedAt: number;
};

export type VfsMap = Record<string, VfsEntry>;

export type TerminalLine = {
  id: string;
  kind: "in" | "out" | "sys" | "err";
  text: string;
};

export type ApiChatMessage = {
  role: Role;
  content: string;
  toolCalls?: ToolCall[];
  toolCallId?: string;
};
