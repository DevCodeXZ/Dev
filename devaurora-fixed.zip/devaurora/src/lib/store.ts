import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_MODEL_ID } from "./models";
import type { Chat, ChatMessage, TerminalLine, VfsMap } from "./types";
import {
  allFiles,
  exists,
  isDir,
  normalizePath,
  readFile,
  seedVfs,
  WORKSPACE,
  writeFile,
} from "./vfs";

type Theme = "dark" | "light";

type AppState = {
  theme: Theme;
  sidebarOpen: boolean;
  terminalOpen: boolean;
  workspaceOpen: boolean;
  modelId: string;
  chats: Chat[];
  activeChatId: string | null;
  vfs: VfsMap;
  cwd: string;
  openFilePath: string | null;
  terminalLines: TerminalLine[];
  commandHistory: string[];
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  setTheme: (t: Theme) => void;
  setSidebarOpen: (v: boolean) => void;
  toggleSidebar: () => void;
  setTerminalOpen: (v: boolean) => void;
  setWorkspaceOpen: (v: boolean) => void;
  setModelId: (id: string) => void;
  setCwd: (cwd: string) => void;
  setOpenFilePath: (path: string | null) => void;
  newChat: () => string;
  setActiveChat: (id: string | null) => void;
  renameChat: (id: string, title: string) => void;
  deleteChat: (id: string) => void;
  clearChats: () => void;
  commitMessages: (chatId: string, messages: ChatMessage[], title?: string) => void;
  writeVfsFile: (path: string, content: string) => void;
  readVfsFile: (path: string) => string;
  setVfs: (vfs: VfsMap) => void;
  resetWorkspace: () => void;
  pushTerminal: (line: Omit<TerminalLine, "id">) => void;
  clearTerminal: () => void;
  pushHistory: (cmd: string) => void;
};

function uid(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
  return "id-" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return "Nuevo chat";
  return clean.length > 42 ? clean.slice(0, 42) + "…" : clean;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: "dark",
      sidebarOpen: true,
      terminalOpen: false,
      workspaceOpen: false,
      modelId: DEFAULT_MODEL_ID,
      chats: [],
      activeChatId: null,
      vfs: seedVfs(),
      cwd: WORKSPACE,
      openFilePath: "/workspace/README.md",
      terminalLines: [
        {
          id: "boot",
          kind: "sys",
          text: "DevAurora Shell v1.0 — escribe `help` para ver comandos. Python, Node, C, Rust, Go y 80+ lenguajes listos.",
        },
      ],
      commandHistory: [],
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      setTheme: (theme) => {
        set({ theme });
        if (typeof document !== "undefined") {
          document.documentElement.classList.toggle("light", theme === "light");
        }
      },
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      toggleSidebar: () => set({ sidebarOpen: !get().sidebarOpen }),
      setTerminalOpen: (terminalOpen) => set({ terminalOpen }),
      setWorkspaceOpen: (workspaceOpen) => set({ workspaceOpen }),
      setModelId: (modelId) => set({ modelId }),
      setCwd: (cwd) => set({ cwd: normalizePath(cwd) }),
      setOpenFilePath: (openFilePath) => set({ openFilePath }),
      newChat: () => {
        const id = uid();
        const chat: Chat = {
          id,
          title: "Nuevo chat",
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        set({ chats: [chat, ...get().chats].slice(0, 40), activeChatId: id });
        return id;
      },
      setActiveChat: (activeChatId) => set({ activeChatId }),
      renameChat: (id, title) =>
        set({
          chats: get().chats.map((c) => (c.id === id ? { ...c, title } : c)),
        }),
      deleteChat: (id) => {
        const chats = get().chats.filter((c) => c.id !== id);
        const activeChatId =
          get().activeChatId === id ? (chats[0]?.id ?? null) : get().activeChatId;
        set({ chats, activeChatId });
      },
      clearChats: () => set({ chats: [], activeChatId: null }),
      commitMessages: (chatId, messages, title) => {
        set({
          chats: get().chats.map((c) =>
            c.id === chatId
              ? {
                  ...c,
                  messages,
                  title:
                    title ??
                    (c.title === "Nuevo chat" && messages.find((m) => m.role === "user")
                      ? titleFrom(messages.find((m) => m.role === "user")!.content)
                      : c.title),
                  updatedAt: Date.now(),
                }
              : c,
          ),
        });
      },
      writeVfsFile: (path, content) => {
        set({ vfs: writeFile(get().vfs, path, content) });
      },
      readVfsFile: (path) => readFile(get().vfs, path),
      setVfs: (vfs) => set({ vfs }),
      resetWorkspace: () =>
        set({
          vfs: seedVfs(),
          cwd: WORKSPACE,
          openFilePath: "/workspace/README.md",
        }),
      pushTerminal: (line) =>
        set({
          terminalLines: [
            ...get().terminalLines,
            { ...line, id: uid() },
          ].slice(-800),
        }),
      clearTerminal: () => set({ terminalLines: [] }),
      pushHistory: (cmd) => {
        const trimmed = cmd.trim();
        if (!trimmed) return;
        const prev = get().commandHistory.filter((c) => c !== trimmed);
        set({ commandHistory: [...prev, trimmed].slice(-200) });
      },
    }),
    {
      name: "deva-aurora-v1",
      partialize: (s) => ({
        theme: s.theme,
        sidebarOpen: s.sidebarOpen,
        terminalOpen: s.terminalOpen,
        workspaceOpen: s.workspaceOpen,
        modelId: s.modelId,
        chats: s.chats,
        activeChatId: s.activeChatId,
        vfs: s.vfs,
        cwd: s.cwd,
        openFilePath: s.openFilePath,
        terminalLines: s.terminalLines.slice(-200),
        commandHistory: s.commandHistory,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
        if (state?.theme === "light" && typeof document !== "undefined") {
          document.documentElement.classList.add("light");
        }
      },
    },
  ),
);

export function workspaceSummary(): { cwd: string; files: string[] } {
  const { cwd, vfs } = useAppStore.getState();
  return { cwd, files: allFiles(vfs) };
}

export function fileExists(path: string): boolean {
  return exists(useAppStore.getState().vfs, path);
}

export function dirExists(path: string): boolean {
  return isDir(useAppStore.getState().vfs, path);
}

export { uid };
