-- ========================================
-- Path: Workspace.Mszh2020.Animate
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v_u_1 = script.Parent
local v_u_2 = v_u_1:WaitForChild("Humanoid")
local v_u_3 = "Standing"
local function v_u_4() -- name: getRigScale
	-- upvalues: (copy) v_u_1
	return v_u_1:GetScale()
end
local v_u_5 = script:FindFirstChild("ScaleDampeningPercent")
local v6, v7 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAnimateRemoveEmoteChatHook")
end)
local v8 = v6 and v7
local v_u_9 = ""
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = 1
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {
	["idle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507766666",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766951",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766388",
			["weight"] = 9
		}
	},
	["walk"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777826",
			["weight"] = 10
		}
	},
	["run"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767714",
			["weight"] = 10
		}
	},
	["swim"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507784897",
			["weight"] = 10
		}
	},
	["swimidle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507785072",
			["weight"] = 10
		}
	},
	["jump"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765000",
			["weight"] = 10
		}
	},
	["fall"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767968",
			["weight"] = 10
		}
	},
	["climb"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765644",
			["weight"] = 10
		}
	},
	["sit"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=2506281703",
			["weight"] = 10
		}
	},
	["toolnone"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507768375",
			["weight"] = 10
		}
	},
	["toolslash"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522635514",
			["weight"] = 10
		}
	},
	["toollunge"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522638767",
			["weight"] = 10
		}
	},
	["wave"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770239",
			["weight"] = 10
		}
	},
	["point"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770453",
			["weight"] = 10
		}
	},
	["dance"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507771019",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507771955",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507772104",
			["weight"] = 10
		}
	},
	["dance2"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507776043",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776720",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776879",
			["weight"] = 10
		}
	},
	["dance3"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777268",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777451",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777623",
			["weight"] = 10
		}
	},
	["laugh"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770818",
			["weight"] = 10
		}
	},
	["cheer"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770677",
			["weight"] = 10
		}
	}
}
local v_u_19 = {
	["wave"] = false,
	["point"] = false,
	["dance"] = true,
	["dance2"] = true,
	["dance3"] = true,
	["laugh"] = false,
	["cheer"] = false
}
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v25, v26 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAnimationAbilityManagerFixed")
end)
local v_u_27 = v25 and v26
function resetManagerListeners() -- name: resetManagerListeners
	-- upvalues: (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	if v_u_20 then
		v_u_20:Disconnect()
		v_u_20 = nil
	end
	if v_u_21 then
		v_u_21:Disconnect()
		v_u_21 = nil
	end
	if v_u_22 then
		v_u_22:Disconnect()
		v_u_22 = nil
	end
end
function teardownManager() -- name: teardownManager
	-- upvalues: (ref) v_u_23, (ref) v_u_24
	resetManagerListeners()
	v_u_23 = nil
	v_u_24 = nil
end
function processIfManagerBelongsToCharacter(p_u_28) -- name: processIfManagerBelongsToCharacter
	-- upvalues: (copy) v_u_1, (ref) v_u_24, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	if p_u_28.RootPart ~= v_u_1.PrimaryPart then
		return false
	end
	if v_u_24 ~= p_u_28 then
		resetManagerListeners()
		v_u_23 = p_u_28.GroundSensor
		v_u_20 = p_u_28:GetPropertyChangedSignal("GroundSensor"):Connect(function()
			-- upvalues: (copy) p_u_28, (ref) v_u_20
			if processIfManagerBelongsToCharacter(p_u_28) then
				v_u_20:Disconnect()
				v_u_20 = nil
			end
		end)
		v_u_21 = p_u_28:GetPropertyChangedSignal("RootPart"):Connect(function()
			-- upvalues: (copy) p_u_28, (ref) v_u_21
			if processIfManagerBelongsToCharacter(p_u_28) then
				v_u_21:Disconnect()
				v_u_21 = nil
			end
		end)
		v_u_22 = p_u_28.AncestryChanged:Connect(function(_, p29)
			if p29 == nil then
				resetManagerListeners()
				lookForControllerManager()
			end
		end)
		v_u_24 = p_u_28
	end
	return true
end
function setupManager(p_u_30) -- name: setupManager
	-- upvalues: (ref) v_u_24, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (copy) v_u_1, (ref) v_u_22
	v_u_24 = p_u_30
	v_u_23 = p_u_30.GroundSensor
	v_u_20 = p_u_30:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		-- upvalues: (ref) v_u_23, (ref) v_u_24
		v_u_23 = v_u_24.GroundSensor
	end)
	v_u_21 = p_u_30:GetPropertyChangedSignal("RootPart"):Connect(function()
		-- upvalues: (copy) p_u_30, (ref) v_u_1
		if p_u_30.RootPart ~= v_u_1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)
	v_u_22 = p_u_30.AncestryChanged:Connect(function(_, p31)
		if p31 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end
function lookForControllerManager() -- name: lookForControllerManager
	-- upvalues: (ref) v_u_27, (copy) v_u_1, (ref) v_u_23, (ref) v_u_24
	if v_u_27 then
		local v_u_32 = v_u_1:FindFirstChildOfClass("ControllerManager")
		if v_u_32 then
			if v_u_32.RootPart == v_u_1.PrimaryPart then
				setupManager(v_u_32)
			else
				local v_u_33 = nil
				v_u_33 = v_u_32:GetPropertyChangedSignal("RootPart"):Connect(function()
					-- upvalues: (copy) v_u_32, (ref) v_u_1, (ref) v_u_33
					if v_u_32.RootPart == v_u_1.PrimaryPart then
						v_u_33:Disconnect()
						setupManager(v_u_32)
					end
				end)
			end
		else
			local v_u_34 = nil
			v_u_34 = v_u_1.ChildAdded:Connect(function(p35)
				-- upvalues: (ref) v_u_34
				if p35:IsA("ControllerManager") then
					v_u_34:Disconnect()
					lookForControllerManager()
				end
			end)
			return
		end
	else
		v_u_23 = nil
		v_u_24 = nil
		local v36 = v_u_1:FindFirstChildOfClass("ControllerManager")
		if v36 then
			processIfManagerBelongsToCharacter(v36)
		end
		if v_u_24 == nil then
			local v_u_37 = nil
			v_u_37 = v_u_1.ChildAdded:Connect(function(p38)
				-- upvalues: (ref) v_u_37
				if p38:IsA("ControllerManager") and processIfManagerBelongsToCharacter(p38) then
					v_u_37:Disconnect()
					v_u_37 = nil
				end
			end)
		end
		return
	end
end
lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(p39, p40) -- name: findExistingAnimationInSet
	if p39 == nil or p40 == nil then
		return 0
	end
	for v41 = 1, p39.count do
		if p39[v41].anim.AnimationId == p40.AnimationId then
			return v41
		end
	end
	return 0
end
function configureAnimationSet(p_u_42, p_u_43) -- name: configureAnimationSet
	-- upvalues: (copy) v_u_17, (copy) v_u_16, (copy) v_u_2
	if v_u_17[p_u_42] ~= nil then
		for _, v44 in pairs(v_u_17[p_u_42].connections) do
			v44:disconnect()
		end
	end
	v_u_17[p_u_42] = {}
	v_u_17[p_u_42].count = 0
	v_u_17[p_u_42].totalWeight = 0
	v_u_17[p_u_42].connections = {}
	local v_u_45 = true
	local v46, _ = pcall(function()
		-- upvalues: (ref) v_u_45
		v_u_45 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)
	v_u_45 = not v46 and true or v_u_45
	local v47 = script:FindFirstChild(p_u_42)
	if v_u_45 and v47 ~= nil then
		local v48 = v_u_17[p_u_42].connections
		local v49 = v47.ChildAdded
		table.insert(v48, v49:connect(function(_)
			-- upvalues: (copy) p_u_42, (copy) p_u_43
			configureAnimationSet(p_u_42, p_u_43)
		end))
		local v50 = v_u_17[p_u_42].connections
		local v51 = v47.ChildRemoved
		table.insert(v50, v51:connect(function(_)
			-- upvalues: (copy) p_u_42, (copy) p_u_43
			configureAnimationSet(p_u_42, p_u_43)
		end))
		for _, v52 in pairs(v47:GetChildren()) do
			if v52:IsA("Animation") then
				local v53 = v52:FindFirstChild("Weight")
				local v54 = v53 == nil and 1 or v53.Value
				v_u_17[p_u_42].count = v_u_17[p_u_42].count + 1
				local v55 = v_u_17[p_u_42].count
				v_u_17[p_u_42][v55] = {}
				v_u_17[p_u_42][v55].anim = v52
				v_u_17[p_u_42][v55].weight = v54
				v_u_17[p_u_42].totalWeight = v_u_17[p_u_42].totalWeight + v_u_17[p_u_42][v55].weight
				local v56 = v_u_17[p_u_42].connections
				local v57 = v52.Changed
				table.insert(v56, v57:connect(function(_)
					-- upvalues: (copy) p_u_42, (copy) p_u_43
					configureAnimationSet(p_u_42, p_u_43)
				end))
				local v58 = v_u_17[p_u_42].connections
				local v59 = v52.ChildAdded
				table.insert(v58, v59:connect(function(_)
					-- upvalues: (copy) p_u_42, (copy) p_u_43
					configureAnimationSet(p_u_42, p_u_43)
				end))
				local v60 = v_u_17[p_u_42].connections
				local v61 = v52.ChildRemoved
				table.insert(v60, v61:connect(function(_)
					-- upvalues: (copy) p_u_42, (copy) p_u_43
					configureAnimationSet(p_u_42, p_u_43)
				end))
			end
		end
	end
	if v_u_17[p_u_42].count <= 0 then
		for v62, v63 in pairs(p_u_43) do
			v_u_17[p_u_42][v62] = {}
			v_u_17[p_u_42][v62].anim = Instance.new("Animation")
			v_u_17[p_u_42][v62].anim.Name = p_u_42
			v_u_17[p_u_42][v62].anim.AnimationId = v63.id
			v_u_17[p_u_42][v62].weight = v63.weight
			v_u_17[p_u_42].count = v_u_17[p_u_42].count + 1
			v_u_17[p_u_42].totalWeight = v_u_17[p_u_42].totalWeight + v63.weight
		end
	end
	for _, v64 in pairs(v_u_17) do
		for v65 = 1, v64.count do
			if v_u_16[v64[v65].anim.AnimationId] == nil then
				v_u_2:LoadAnimation(v64[v65].anim)
				v_u_16[v64[v65].anim.AnimationId] = true
			end
		end
	end
end
function configureAnimationSetOld(p_u_66, p_u_67) -- name: configureAnimationSetOld
	-- upvalues: (copy) v_u_17, (copy) v_u_2
	if v_u_17[p_u_66] ~= nil then
		for _, v68 in pairs(v_u_17[p_u_66].connections) do
			v68:disconnect()
		end
	end
	v_u_17[p_u_66] = {}
	v_u_17[p_u_66].count = 0
	v_u_17[p_u_66].totalWeight = 0
	v_u_17[p_u_66].connections = {}
	local v_u_69 = true
	local v70, _ = pcall(function()
		-- upvalues: (ref) v_u_69
		v_u_69 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)
	v_u_69 = not v70 and true or v_u_69
	local v71 = script:FindFirstChild(p_u_66)
	if v_u_69 and v71 ~= nil then
		local v72 = v_u_17[p_u_66].connections
		local v73 = v71.ChildAdded
		table.insert(v72, v73:connect(function(_)
			-- upvalues: (copy) p_u_66, (copy) p_u_67
			configureAnimationSet(p_u_66, p_u_67)
		end))
		local v74 = v_u_17[p_u_66].connections
		local v75 = v71.ChildRemoved
		table.insert(v74, v75:connect(function(_)
			-- upvalues: (copy) p_u_66, (copy) p_u_67
			configureAnimationSet(p_u_66, p_u_67)
		end))
		local v76 = 1
		for _, v77 in pairs(v71:GetChildren()) do
			if v77:IsA("Animation") then
				local v78 = v_u_17[p_u_66].connections
				local v79 = v77.Changed
				table.insert(v78, v79:connect(function(_)
					-- upvalues: (copy) p_u_66, (copy) p_u_67
					configureAnimationSet(p_u_66, p_u_67)
				end))
				v_u_17[p_u_66][v76] = {}
				v_u_17[p_u_66][v76].anim = v77
				local v80 = v77:FindFirstChild("Weight")
				if v80 == nil then
					v_u_17[p_u_66][v76].weight = 1
				else
					v_u_17[p_u_66][v76].weight = v80.Value
				end
				v_u_17[p_u_66].count = v_u_17[p_u_66].count + 1
				v_u_17[p_u_66].totalWeight = v_u_17[p_u_66].totalWeight + v_u_17[p_u_66][v76].weight
				v76 = v76 + 1
			end
		end
	end
	if v_u_17[p_u_66].count <= 0 then
		for v81, v82 in pairs(p_u_67) do
			v_u_17[p_u_66][v81] = {}
			v_u_17[p_u_66][v81].anim = Instance.new("Animation")
			v_u_17[p_u_66][v81].anim.Name = p_u_66
			v_u_17[p_u_66][v81].anim.AnimationId = v82.id
			v_u_17[p_u_66][v81].weight = v82.weight
			v_u_17[p_u_66].count = v_u_17[p_u_66].count + 1
			v_u_17[p_u_66].totalWeight = v_u_17[p_u_66].totalWeight + v82.weight
		end
	end
	for _, v83 in pairs(v_u_17) do
		for v84 = 1, v83.count do
			v_u_2:LoadAnimation(v83[v84].anim)
		end
	end
end
function scriptChildModified(p85) -- name: scriptChildModified
	-- upvalues: (copy) v_u_18
	local v86 = v_u_18[p85.Name]
	if v86 ~= nil then
		configureAnimationSet(p85.Name, v86)
	end
end
script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local v87
if v_u_2 then
	v87 = v_u_2:FindFirstChildOfClass("Animator")
else
	v87 = nil
end
local v_u_88, v_u_89
if v87 then
	local v90 = v87:GetPlayingAnimationTracks()
	v_u_88 = v_u_24
	v_u_89 = v_u_23
	for _, v91 in ipairs(v90) do
		v91:Stop(0)
		v91:Destroy()
	end
else
	v_u_88 = v_u_24
	v_u_89 = v_u_23
end
for v92, v93 in pairs(v_u_18) do
	configureAnimationSet(v92, v93)
end
local v_u_94 = "None"
local v_u_95 = 0
local v_u_96 = 0
local v_u_97 = false
function stopAllAnimations() -- name: stopAllAnimations
	-- upvalues: (ref) v_u_9, (copy) v_u_19, (ref) v_u_97, (ref) v_u_10, (ref) v_u_12, (ref) v_u_11, (ref) v_u_15, (ref) v_u_14
	local v98 = v_u_9
	local v99 = v_u_19[v98] ~= nil and v_u_19[v98] == false and "idle" or v98
	if v_u_97 then
		v99 = "idle"
		v_u_97 = false
	end
	v_u_9 = ""
	v_u_10 = nil
	if v_u_12 ~= nil then
		v_u_12:disconnect()
	end
	if v_u_11 ~= nil then
		v_u_11:Stop()
		v_u_11:Destroy()
		v_u_11 = nil
	end
	if v_u_15 ~= nil then
		v_u_15:disconnect()
	end
	if v_u_14 ~= nil then
		v_u_14:Stop()
		v_u_14:Destroy()
		v_u_14 = nil
	end
	return v99
end
function getHeightScale() -- name: getHeightScale
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_5
	if not v_u_2 then
		return v_u_4()
	end
	if not v_u_2.AutomaticScalingEnabled then
		return v_u_4()
	end
	local v100 = v_u_2.HipHeight / 2
	if v_u_5 == nil then
		v_u_5 = script:FindFirstChild("ScaleDampeningPercent")
	end
	if v_u_5 ~= nil then
		v100 = 1 + (v_u_2.HipHeight - 2) * v_u_5.Value / 2
	end
	return v100
end
local function v_u_106(p101) -- name: setRunSpeed
	-- upvalues: (ref) v_u_11, (ref) v_u_14
	local v102 = p101 * 1.25 / getHeightScale()
	local v103 = 0.0001
	local v104 = 0.0001
	local v105 = 1
	if v102 <= 0.5 then
		v105 = v102 / 0.5
		v103 = 1
	elseif v102 < 1 then
		v104 = (v102 - 0.5) / 0.5
		v103 = 1 - v104
	else
		v105 = v102 / 1
		v104 = 1
	end
	v_u_11:AdjustWeight(v103)
	v_u_14:AdjustWeight(v104)
	v_u_11:AdjustSpeed(v105)
	v_u_14:AdjustSpeed(v105)
end
function setAnimationSpeed(p107) -- name: setAnimationSpeed
	-- upvalues: (ref) v_u_9, (copy) v_u_106, (ref) v_u_13, (ref) v_u_11
	if v_u_9 == "walk" then
		v_u_106(p107)
	elseif p107 ~= v_u_13 then
		v_u_13 = p107
		v_u_11:AdjustSpeed(v_u_13)
	end
end
function keyFrameReachedFunc(p108) -- name: keyFrameReachedFunc
	-- upvalues: (ref) v_u_9, (ref) v_u_14, (ref) v_u_11, (copy) v_u_19, (ref) v_u_97, (ref) v_u_13, (copy) v_u_2
	if p108 == "End" then
		if v_u_9 == "walk" then
			if v_u_14.Looped ~= true then
				v_u_14.TimePosition = 0
			end
			if v_u_11.Looped ~= true then
				v_u_11.TimePosition = 0
				return
			end
		else
			local v109 = v_u_9
			local v110 = v_u_19[v109] ~= nil and v_u_19[v109] == false and "idle" or v109
			if v_u_97 then
				if v_u_11.Looped then
					return
				end
				v110 = "idle"
				v_u_97 = false
			end
			local v111 = v_u_13
			playAnimation(v110, 0.15, v_u_2)
			setAnimationSpeed(v111)
		end
	end
end
function rollAnimation(p112) -- name: rollAnimation
	-- upvalues: (copy) v_u_17
	local v113 = math.random(1, v_u_17[p112].totalWeight)
	local v114 = 1
	while v_u_17[p112][v114].weight < v113 do
		v113 = v113 - v_u_17[p112][v114].weight
		v114 = v114 + 1
	end
	return v114
end
local function v_u_120(p115, p116, p117, p118) -- name: switchToAnim
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_14, (ref) v_u_13, (ref) v_u_9, (ref) v_u_12, (copy) v_u_17, (ref) v_u_15
	if p115 ~= v_u_10 then
		if v_u_11 ~= nil then
			v_u_11:Stop(p117)
			v_u_11:Destroy()
		end
		if v_u_14 ~= nil then
			v_u_14:Stop(p117)
			v_u_14:Destroy()
			v_u_14 = nil
		end
		v_u_13 = 1
		v_u_11 = p118:LoadAnimation(p115)
		v_u_11.Priority = Enum.AnimationPriority.Core
		v_u_11:Play(p117)
		v_u_9 = p116
		v_u_10 = p115
		if v_u_12 ~= nil then
			v_u_12:disconnect()
		end
		v_u_12 = v_u_11.KeyframeReached:connect(keyFrameReachedFunc)
		if p116 == "walk" then
			local v119 = rollAnimation("run")
			v_u_14 = p118:LoadAnimation(v_u_17.run[v119].anim)
			v_u_14.Priority = Enum.AnimationPriority.Core
			v_u_14:Play(p117)
			if v_u_15 ~= nil then
				v_u_15:disconnect()
			end
			v_u_15 = v_u_14.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end
function playAnimation(p121, p122, p123) -- name: playAnimation
	-- upvalues: (copy) v_u_17, (copy) v_u_120, (ref) v_u_97
	local v124 = rollAnimation(p121)
	v_u_120(v_u_17[p121][v124].anim, p121, p122, p123)
	v_u_97 = false
end
function playEmote(p125, p126, p127) -- name: playEmote
	-- upvalues: (copy) v_u_120, (ref) v_u_97
	v_u_120(p125, p125.Name, p126, p127)
	v_u_97 = true
end
local v_u_128 = ""
local v_u_129 = nil
local v_u_130 = nil
local v_u_131 = nil
function toolKeyFrameReachedFunc(p132) -- name: toolKeyFrameReachedFunc
	-- upvalues: (ref) v_u_128, (copy) v_u_2
	if p132 == "End" then
		playToolAnimation(v_u_128, 0, v_u_2)
	end
end
function playToolAnimation(p133, p134, p135, p136) -- name: playToolAnimation
	-- upvalues: (copy) v_u_17, (ref) v_u_130, (ref) v_u_129, (ref) v_u_128, (ref) v_u_131
	local v137 = rollAnimation(p133)
	local v138 = v_u_17[p133][v137].anim
	if v_u_130 ~= v138 then
		if v_u_129 ~= nil then
			v_u_129:Stop()
			v_u_129:Destroy()
			p134 = 0
		end
		v_u_129 = p135:LoadAnimation(v138)
		if p136 then
			v_u_129.Priority = p136
		end
		v_u_129:Play(p134)
		v_u_128 = p133
		v_u_130 = v138
		v_u_131 = v_u_129.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end
function stopToolAnimations() -- name: stopToolAnimations
	-- upvalues: (ref) v_u_128, (ref) v_u_131, (ref) v_u_130, (ref) v_u_129
	local v139 = v_u_128
	if v_u_131 ~= nil then
		v_u_131:disconnect()
	end
	v_u_128 = ""
	v_u_130 = nil
	if v_u_129 ~= nil then
		v_u_129:Stop()
		v_u_129:Destroy()
		v_u_129 = nil
	end
	return v139
end
function onRunning(p140) -- name: onRunning
	-- upvalues: (ref) v_u_89, (copy) v_u_2, (ref) v_u_88, (ref) v_u_97, (ref) v_u_3, (copy) v_u_19, (ref) v_u_9
	local v141 = getHeightScale()
	if v_u_89 ~= nil and v_u_2.EvaluateStateMachine == false then
		local v142 = v_u_2.RootPart
		local v143 = v_u_89.SensedPart
		if v143 then
			local v144 = v143:GetVelocityAtPosition(v_u_89.HitFrame.Position)
			local v145 = v142.AssemblyLinearVelocity
			local v146 = v145.X - v144.X
			local v147 = v145.Z - v144.Z
			local v148 = Vector3.new(v146, 0, v147).Magnitude
			local v149 = v_u_88.MovingDirection.Magnitude
			if v149 < 0.1 then
				v148 = 0
				v149 = 0
			elseif v149 > 1 then
				v149 = 1
			end
			p140 = v148 * v149
		end
	end
	local v150 = v_u_97
	if v150 then
		v150 = v_u_2.MoveDirection == Vector3.new(0, 0, 0)
	end
	if (v150 and (v_u_2.WalkSpeed / v141 or 0.75) or 0.75) * v141 < p140 then
		playAnimation("walk", 0.2, v_u_2)
		setAnimationSpeed(p140 / 16)
		v_u_3 = "Running"
	elseif v_u_19[v_u_9] == nil and not v_u_97 then
		playAnimation("idle", 0.2, v_u_2)
		v_u_3 = "Standing"
	end
end
function onDied() -- name: onDied
	-- upvalues: (ref) v_u_3
	v_u_3 = "Dead"
end
function onJumping() -- name: onJumping
	-- upvalues: (copy) v_u_2, (ref) v_u_96, (ref) v_u_3
	playAnimation("jump", 0.1, v_u_2)
	v_u_96 = 0.31
	v_u_3 = "Jumping"
end
function onClimbing(p151) -- name: onClimbing
	-- upvalues: (copy) v_u_2, (ref) v_u_3
	local v152 = p151 / getHeightScale()
	playAnimation("climb", 0.1, v_u_2)
	setAnimationSpeed(v152 / 5)
	v_u_3 = "Climbing"
end
function onGettingUp() -- name: onGettingUp
	-- upvalues: (ref) v_u_3
	v_u_3 = "GettingUp"
end
function onFreeFall() -- name: onFreeFall
	-- upvalues: (ref) v_u_96, (copy) v_u_2, (ref) v_u_3
	if v_u_96 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	end
	v_u_3 = "FreeFall"
end
function onFallingDown() -- name: onFallingDown
	-- upvalues: (ref) v_u_3
	v_u_3 = "FallingDown"
end
function onSeated() -- name: onSeated
	-- upvalues: (ref) v_u_3
	v_u_3 = "Seated"
end
function onPlatformStanding() -- name: onPlatformStanding
	-- upvalues: (ref) v_u_3
	v_u_3 = "PlatformStanding"
end
function onSwimming(p153) -- name: onSwimming
	-- upvalues: (copy) v_u_2, (ref) v_u_3
	local v154 = p153 / getHeightScale()
	if v154 > 1 then
		playAnimation("swim", 0.4, v_u_2)
		setAnimationSpeed(v154 / 10)
		v_u_3 = "Swimming"
	else
		playAnimation("swimidle", 0.4, v_u_2)
		v_u_3 = "Standing"
	end
end
function animateTool() -- name: animateTool
	-- upvalues: (ref) v_u_94, (copy) v_u_2
	if v_u_94 == "None" then
		playToolAnimation("toolnone", 0.1, v_u_2, Enum.AnimationPriority.Idle)
		return
	elseif v_u_94 == "Slash" then
		playToolAnimation("toolslash", 0, v_u_2, Enum.AnimationPriority.Action)
		return
	elseif v_u_94 == "Lunge" then
		playToolAnimation("toollunge", 0, v_u_2, Enum.AnimationPriority.Action)
	end
end
function getToolAnim(p155) -- name: getToolAnim
	for _, v156 in ipairs(p155:GetChildren()) do
		if v156.Name == "toolanim" and v156.className == "StringValue" then
			return v156
		end
	end
	return nil
end
local v_u_157 = 0
function stepAnimate(p158) -- name: stepAnimate
	-- upvalues: (ref) v_u_157, (ref) v_u_96, (ref) v_u_3, (copy) v_u_2, (copy) v_u_1, (ref) v_u_94, (ref) v_u_95, (ref) v_u_130
	local v159 = p158 - v_u_157
	v_u_157 = p158
	if v_u_96 > 0 then
		v_u_96 = v_u_96 - v159
	end
	if v_u_3 == "FreeFall" and v_u_96 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	else
		if v_u_3 == "Seated" then
			playAnimation("sit", 0.5, v_u_2)
			return
		end
		if v_u_3 == "Running" then
			playAnimation("walk", 0.2, v_u_2)
		elseif v_u_3 == "Dead" or (v_u_3 == "GettingUp" or (v_u_3 == "FallingDown" or (v_u_3 == "Seated" or v_u_3 == "PlatformStanding"))) then
			stopAllAnimations()
		end
	end
	local v160 = v_u_1:FindFirstChildOfClass("Tool")
	if v160 and v160:FindFirstChild("Handle") then
		local v161 = getToolAnim(v160)
		if v161 then
			v_u_94 = v161.Value
			v161.Parent = nil
			v_u_95 = p158 + 0.3
		end
		if v_u_95 < p158 then
			v_u_95 = 0
			v_u_94 = "None"
		end
		animateTool()
	else
		stopToolAnimations()
		v_u_94 = "None"
		v_u_130 = nil
		v_u_95 = 0
	end
end
v_u_2.Died:connect(onDied)
v_u_2.Running:connect(onRunning)
v_u_2.Jumping:connect(onJumping)
v_u_2.Climbing:connect(onClimbing)
v_u_2.GettingUp:connect(onGettingUp)
v_u_2.FreeFalling:connect(onFreeFall)
v_u_2.FallingDown:connect(onFallingDown)
v_u_2.Seated:connect(onSeated)
v_u_2.PlatformStanding:connect(onPlatformStanding)
v_u_2.Swimming:connect(onSwimming)
if not v8 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(p162)
		-- upvalues: (ref) v_u_3, (copy) v_u_19, (copy) v_u_2
		local v163 = ""
		if string.sub(p162, 1, 3) == "/e " then
			v163 = string.sub(p162, 4)
		elseif string.sub(p162, 1, 7) == "/emote " then
			v163 = string.sub(p162, 8)
		end
		if v_u_3 == "Standing" and v_u_19[v163] ~= nil then
			playAnimation(v163, 0.1, v_u_2)
		end
	end)
end
script:WaitForChild("PlayEmote").OnInvoke = function(p164)
	-- upvalues: (ref) v_u_3, (copy) v_u_19, (copy) v_u_2, (ref) v_u_11
	if v_u_3 == "Standing" then
		if v_u_19[p164] ~= nil then
			playAnimation(p164, 0.1, v_u_2)
			return true, v_u_11
		end
		if typeof(p164) ~= "Instance" or not p164:IsA("Animation") then
			return false
		end
		playEmote(p164, 0.1, v_u_2)
		return true, v_u_11
	end
end
if v_u_1.Parent ~= nil then
	playAnimation("idle", 0.1, v_u_2)
	local _ = "Standing"
end
while v_u_1.Parent ~= nil do
	local _, v165 = wait(0.1)
	stepAnimate(v165)
end