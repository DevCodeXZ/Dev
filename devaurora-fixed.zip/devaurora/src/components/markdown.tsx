import { useState, type ReactNode } from "react";
import { Check, Copy, Play } from "lucide-react";
import { cn } from "@/lib/cn";
import { executeSnippet } from "@/lib/shell";
import { resolveLanguage } from "@/lib/languages";

function escapeSplit(text: string, re: RegExp, wrap: (s: string, i: number) => ReactNode): ReactNode[] {
  const parts: ReactNode[] = [];
  let last = 0;
  let i = 0;
  const clone = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g");
  let m: RegExpExecArray | null;
  while ((m = clone.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(wrap(m[1] ?? m[0], i++));
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

function Inline({ text }: { text: string }) {
  const nodes = escapeSplit(text, /`([^`]+)`/, (s, i) => (
    <code key={`c${i}`} className="inline-code">
      {s}
    </code>
  ));
  return (
    <>
      {nodes.map((node, idx) => {
        if (typeof node !== "string") return <span key={idx}>{node}</span>;
        return (
          <span key={idx}>
            {escapeSplit(node, /\*\*([^*]+)\*\*/, (s, i) => (
              <strong key={i}>{s}</strong>
            )).map((n2, j) => {
              if (typeof n2 !== "string") return <span key={j}>{n2}</span>;
              return (
                <span key={j}>
                  {escapeSplit(n2, /(?<!\*)\*([^*]+)\*(?!\*)/, (s, i) => (
                    <em key={i}>{s}</em>
                  )).map((n3, k) => {
                    if (typeof n3 !== "string") return <span key={k}>{n3}</span>;
                    return (
                      <span key={k}>
                        {escapeSplit(n3, /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/, (s, i) => {
                          const match = n3.match(
                            new RegExp(`\\[${s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\]\\((https?:\\/\\/[^\\s)]+)\\)`),
                          );
                          const href = match?.[1] ?? "#";
                          return (
                            <a key={i} href={href} target="_blank" rel="noreferrer">
                              {s}
                            </a>
                          );
                        })}
                      </span>
                    );
                  })}
                </span>
              );
            })}
          </span>
        );
      })}
    </>
  );
}

function CodeBlock({ lang, code }: { lang: string; code: string }) {
  const [copied, setCopied] = useState(false);
  const [running, setRunning] = useState(false);
  const [output, setOutput] = useState<string | null>(null);
  const runnable = Boolean(lang && lang !== "text" && lang !== "markdown" && lang !== "md");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* ignore */
    }
  };

  const run = async () => {
    setRunning(true);
    setOutput(null);
    try {
      const out = await executeSnippet(resolveLanguage(lang || "python"), code);
      setOutput(out || "(sin salida)");
    } catch (e) {
      setOutput(e instanceof Error ? e.message : "Error");
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-border bg-code">
      <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-1.5 text-xs text-muted">
        <span className="font-mono lowercase">{lang || "code"}</span>
        <div className="flex items-center gap-1">
          {runnable ? (
            <button
              type="button"
              onClick={() => void run()}
              disabled={running}
              className="inline-flex h-8 items-center gap-1 rounded-md px-2 text-muted hover:bg-hover hover:text-fg"
            >
              <Play className="size-3.5" />
              {running ? "Ejecutando" : "Ejecutar"}
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => void copy()}
            className="inline-flex h-8 items-center gap-1 rounded-md px-2 text-muted hover:bg-hover hover:text-fg"
          >
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            {copied ? "Copiado" : "Copiar"}
          </button>
        </div>
      </div>
      <pre className="overflow-x-auto p-3 font-mono text-[13px] leading-relaxed text-fg">
        <code>{code}</code>
      </pre>
      {output !== null ? (
        <pre className="border-t border-border bg-term p-3 font-mono text-[12px] leading-relaxed text-term-fg">
          {output}
        </pre>
      ) : null}
    </div>
  );
}

function renderLine(line: string, key: number): ReactNode {
  if (line.startsWith("### ")) return <h3 key={key}><Inline text={line.slice(4)} /></h3>;
  if (line.startsWith("## ")) return <h2 key={key}><Inline text={line.slice(3)} /></h2>;
  if (line.startsWith("# ")) return <h1 key={key}><Inline text={line.slice(2)} /></h1>;
  if (line.startsWith("> "))
    return (
      <blockquote key={key}>
        <Inline text={line.slice(2)} />
      </blockquote>
    );
  if (line.trim() === "---" || line.trim() === "***") return <hr key={key} />;
  return null;
}

function Block({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: ReactNode[] = [];
  let i = 0;
  let para: string[] = [];
  const flushPara = () => {
    if (!para.length) return;
    const joined = para.join("\n");
    out.push(
      <p key={`p${out.length}`}>
        <Inline text={joined} />
      </p>,
    );
    para = [];
  };

  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("|") && line.includes("|")) {
      flushPara();
      const rows: string[][] = [];
      while (i < lines.length && lines[i].startsWith("|")) {
        const cells = lines[i]
          .split("|")
          .slice(1, -1)
          .map((c) => c.trim());
        if (!cells.every((c) => /^:?-{3,}:?$/.test(c))) rows.push(cells);
        i++;
      }
      if (rows.length) {
        const head = rows[0];
        const body = rows.slice(1);
        out.push(
          <table key={`t${out.length}`}>
            <thead>
              <tr>
                {head.map((c, ci) => (
                  <th key={ci}>
                    <Inline text={c} />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {body.map((r, ri) => (
                <tr key={ri}>
                  {r.map((c, ci) => (
                    <td key={ci}>
                      <Inline text={c} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>,
        );
      }
      continue;
    }
    if (/^\s*[-*]\s+/.test(line) || /^\s*\d+\.\s+/.test(line)) {
      flushPara();
      const ordered = /^\s*\d+\.\s+/.test(line);
      const items: string[] = [];
      while (i < lines.length && (/^\s*[-*]\s+/.test(lines[i]) || /^\s*\d+\.\s+/.test(lines[i]))) {
        items.push(lines[i].replace(/^\s*[-*]\s+/, "").replace(/^\s*\d+\.\s+/, ""));
        i++;
      }
      const List = ordered ? "ol" : "ul";
      out.push(
        <List key={`l${out.length}`}>
          {items.map((it, ii) => (
            <li key={ii}>
              <Inline text={it} />
            </li>
          ))}
        </List>,
      );
      continue;
    }
    const special = renderLine(line, out.length);
    if (special) {
      flushPara();
      out.push(special);
      i++;
      continue;
    }
    if (line.trim() === "") {
      flushPara();
      i++;
      continue;
    }
    para.push(line);
    i++;
  }
  flushPara();
  return <>{out}</>;
}

export function Markdown({ text }: { text: string }) {
  const chunks: ReactNode[] = [];
  const re = /```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) {
      chunks.push(<Block key={`b${k++}`} text={text.slice(last, m.index)} />);
    }
    chunks.push(<CodeBlock key={`c${k++}`} lang={m[1] || ""} code={m[2].replace(/\n$/, "")} />);
    last = m.index + m[0].length;
  }
  if (last < text.length) chunks.push(<Block key={`b${k++}`} text={text.slice(last)} />);
  return <div className={cn("da-md max-w-none text-[15px] leading-7 text-fg")}>{chunks}</div>;
}
