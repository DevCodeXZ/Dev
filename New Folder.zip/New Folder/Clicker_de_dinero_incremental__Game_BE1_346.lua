-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.Industry.MainUi.Perks.List.P1.More.BE1
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v_u_1 = game.ReplicatedStorage.CEvents.PlaySound
local v_u_2 = script.Parent.Size
local v_u_3 = script.Parent.Position
script.Parent.Button.MouseEnter:Connect(function()
	local v4 = script.Parent
	v4.ZIndex = v4.ZIndex + 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = true
	end
	if script.Parent:FindFirstChild("ButtonEffectF") then
		script.Parent.ButtonEffectF.Visible = true
	end
end)
script.Parent.Button.MouseLeave:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v5 = script.Parent
	v5.ZIndex = v5.ZIndex - 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = false
	end
	if script.Parent:FindFirstChild("ButtonEffectF") then
		script.Parent.ButtonEffectF.Visible = false
	end
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(v_u_2, "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(v_u_3, "In", "Linear", 0.1, true)
	end
end)
script.Parent.Button.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(UDim2.new(v_u_2.X.Scale / 1.2, 0, v_u_2.Y.Scale / 1.2, 0), "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(UDim2.new(v_u_3.X.Scale + v_u_2.X.Scale / 10, 0, v_u_3.Y.Scale + v_u_2.Y.Scale / 10, 0), "In", "Linear", 0.1, true)
	end
end)
script.Parent.Button.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(v_u_2, "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(v_u_3, "In", "Linear", 0.1, true)
	end
end)
script.Parent.Button.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_1
	v_u_1:Fire("Click")
end)