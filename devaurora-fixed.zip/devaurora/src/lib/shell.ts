import { EXECUTABLE_NAMES, extLanguage, resolveLanguage } from "./languages";
import { useAppStore } from "./store";
import type { VfsMap } from "./types";
import {
  baseName,
  copyPath,
  ensureDir,
  exists,
  formatListing,
  isDir,
  isFile,
  joinPath,
  listDir,
  movePath,
  normalizePath,
  parentPath,
  readFile,
  removePath,
  resolvePath,
  tree,
  writeFile,
} from "./vfs";

export type CommandResult = {
  output: string;
  clear?: boolean;
  openFile?: string;
  closeTerminal?: boolean;
  openWorkspace?: boolean;
};

function tokenize(input: string): string[] {
  const tokens: string[] = [];
  let cur = "";
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quote) {
      if (ch === "\\" && quote === '"' && i + 1 < input.length) {
        cur += input[i + 1];
        i++;
        continue;
      }
      if (ch === quote) {
        quote = null;
        continue;
      }
      cur += ch;
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      continue;
    }
    if (ch === "\\" && i + 1 < input.length) {
      cur += input[i + 1];
      i++;
      continue;
    }
    if (/\s/.test(ch)) {
      if (cur) tokens.push(cur);
      cur = "";
      continue;
    }
    cur += ch;
  }
  if (cur) tokens.push(cur);
  return tokens;
}

function splitPipes(input: string): string[] {
  const parts: string[] = [];
  let cur = "";
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quote) {
      cur += ch;
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      cur += ch;
      continue;
    }
    if (ch === "|") {
      parts.push(cur.trim());
      cur = "";
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts.filter(Boolean);
}

function applyRedirect(tokens: string[]): {
  argv: string[];
  redirect?: { path: string; append: boolean };
} {
  const argv: string[] = [];
  let redirect: { path: string; append: boolean } | undefined;
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    if (t === ">" || t === ">>") {
      const path = tokens[i + 1];
      if (!path) throw new Error("syntax error near unexpected token `newline'");
      redirect = { path, append: t === ">>" };
      i++;
      continue;
    }
    if (t.startsWith(">>") && t.length > 2) {
      redirect = { path: t.slice(2), append: true };
      continue;
    }
    if (t.startsWith(">") && t.length > 1) {
      redirect = { path: t.slice(1), append: false };
      continue;
    }
    argv.push(t);
  }
  return { argv, redirect };
}

async function executeCode(opts: {
  language: string;
  files: { name: string; content: string }[];
  stdin?: string;
  args?: string[];
}): Promise<string> {
  const res = await fetch("/api/execute", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(opts),
  });
  const data = (await res.json()) as {
    ok: boolean;
    stdout?: string;
    stderr?: string;
    error?: string;
    code?: number | null;
    timedOut?: boolean;
    language?: string;
    version?: string;
  };
  const parts: string[] = [];
  if (data.error) parts.push(data.error);
  if (data.stdout) parts.push(data.stdout.replace(/\n$/, ""));
  if (data.stderr) parts.push(data.stderr.replace(/\n$/, ""));
  if (data.timedOut) parts.push("[tiempo agotado]");
  if (!parts.length && data.code && data.code !== 0) {
    parts.push(`exit ${data.code}`);
  }
  return parts.join("\n");
}

function vfsFilesFor(
  map: VfsMap,
  mainPath: string,
): { name: string; content: string }[] {
  const files: { name: string; content: string }[] = [];
  const main = normalizePath(mainPath);
  const mainName = baseName(main);
  if (isFile(map, main)) {
    files.push({ name: mainName, content: readFile(map, main) });
  }
  for (const [path, entry] of Object.entries(map)) {
    if (entry.type !== "file") continue;
    if (path === main) continue;
    const name = path.replace(/^\/workspace\//, "");
    if (name === path) continue;
    if (files.length > 24) break;
    files.push({ name, content: entry.content ?? "" });
  }
  return files;
}

const HELP = `DevAurora Shell — comandos

  Navegación
    ls [-la] [ruta]     listar
    cd [ruta]           cambiar directorio
    pwd                 directorio actual
    tree [ruta]         árbol del workspace
    find [nombre]       buscar archivos

  Archivos
    cat archivo         ver contenido
    head/tail archivo   primeras/últimas líneas
    touch archivo       crear vacío
    mkdir [-p] dir      crear carpeta
    rm [-r] ruta        borrar
    cp origen destino   copiar
    mv origen destino   mover
    echo texto          imprimir  (echo hola > file)
    grep patrón [file]  buscar texto
    wc [file]           contar líneas/palabras
    code archivo        abrir en el editor

  Ejecución (80+ lenguajes)
    python archivo.py
    python -c "print(1)"
    node archivo.js
    ts-node archivo.ts
    gcc archivo.c && ./a.out     (usa: gcc archivo.c)
    rustc, go run, java, ruby, php, lua, bash, ...
    run <lenguaje> <código>

  Sistema
    help, clear, history, date, whoami, hostname
    uname, env, neofetch, reset-workspace
`;

const NEOFETCH = `
      .--.      deva@aurora
     /    \\     -----------
    |  .--. |   OS: DevAurora Linux
    |  |  | |   Host: aurora
     \\ '--' /   Kernel: 6.8.0-deva
      '----'    Shell: dash
                Terminal: DevAurora
                CPU: sandbox
                Languages: 80+
`.trim();

async function runArgv(
  argv: string[],
  stdin: string,
): Promise<{ output: string; extra?: Partial<CommandResult> }> {
  const store = useAppStore.getState();
  const { vfs, cwd } = store;
  const cmd = argv[0] ?? "";
  const args = argv.slice(1);

  const builtin: Record<string, () => { output: string; extra?: Partial<CommandResult> }> = {
    help: () => ({ output: HELP }),
    "?": () => ({ output: HELP }),
    clear: () => ({ output: "", extra: { clear: true } }),
    cls: () => ({ output: "", extra: { clear: true } }),
    pwd: () => ({ output: cwd }),
    whoami: () => ({ output: "deva" }),
    hostname: () => ({ output: "aurora" }),
    date: () => ({ output: new Date().toString() }),
    uname: () => ({
      output:
        args[0] === "-a"
          ? "Linux aurora 6.8.0-deva #1 SMP x86_64 GNU/Linux"
          : "Linux",
    }),
    env: () => ({
      output: ["HOME=/workspace", "USER=deva", "SHELL=/bin/dash", "PWD=" + cwd].join(
        "\n",
      ),
    }),
    printenv: () => ({
      output: ["HOME=/workspace", "USER=deva", "SHELL=/bin/dash", "PWD=" + cwd].join(
        "\n",
      ),
    }),
    history: () => ({ output: store.commandHistory.map((c, i) => `${i + 1}  ${c}`).join("\n") }),
    neofetch: () => ({ output: NEOFETCH }),
    exit: () => ({ output: "", extra: { closeTerminal: true } }),
    logout: () => ({ output: "", extra: { closeTerminal: true } }),
    "reset-workspace": () => {
      store.resetWorkspace();
      return { output: "workspace restaurado" };
    },
  };

  if (builtin[cmd]) return builtin[cmd]();

  if (cmd === "cd") {
    const target = resolvePath(cwd, args[0] ?? "/workspace");
    if (!exists(vfs, target)) return { output: `cd: ${target}: No such file or directory` };
    if (!isDir(vfs, target)) return { output: `cd: ${target}: Not a directory` };
    store.setCwd(target);
    return { output: "" };
  }

  if (cmd === "ls") {
    const flags = args.filter((a) => a.startsWith("-")).join("");
    const pathArg = args.find((a) => !a.startsWith("-"));
    const target = resolvePath(cwd, pathArg ?? ".");
    try {
      if (isFile(vfs, target)) return { output: baseName(target) };
      return {
        output: formatListing(vfs, target, flags.includes("a"), flags.includes("l")),
      };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "tree") {
    const target = resolvePath(cwd, args[0] ?? ".");
    try {
      return { output: tree(vfs, target) };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "mkdir") {
    const p = args.filter((a) => a !== "-p");
    if (!p[0]) return { output: "mkdir: missing operand" };
    try {
      let map = vfs;
      for (const name of p) {
        map = ensureDir(map, resolvePath(cwd, name));
      }
      store.setVfs(map);
      return { output: "" };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "touch") {
    if (!args[0]) return { output: "touch: missing file operand" };
    try {
      let map = vfs;
      for (const name of args) {
        const target = resolvePath(cwd, name);
        if (exists(map, target) && isFile(map, target)) {
          map = writeFile(map, target, readFile(map, target));
        } else {
          map = writeFile(map, target, "");
        }
      }
      store.setVfs(map);
      return { output: "" };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "cat") {
    if (stdin && !args[0]) return { output: stdin };
    if (!args[0]) return { output: "cat: missing file operand" };
    try {
      return {
        output: args
          .map((name) => {
            const target = resolvePath(cwd, name);
            return readFile(vfs, target);
          })
          .join(""),
      };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "head" || cmd === "tail") {
    const nFlag = args.find((a) => a.startsWith("-n")) ?? args.find((a) => a.startsWith("-") && /\d/.test(a));
    let count = 10;
    let fileArgs = args.filter((a) => !a.startsWith("-"));
    if (nFlag) {
      const num = nFlag.replace("-n", "").replace("-", "");
      if (num) count = Number(num) || 10;
      const idx = args.indexOf(nFlag);
      if (!num && args[idx + 1] && !args[idx + 1].startsWith("-") && /^\d+$/.test(args[idx + 1])) {
        count = Number(args[idx + 1]);
        fileArgs = fileArgs.filter((a) => a !== args[idx + 1]);
      }
    }
    const text = fileArgs[0]
      ? readFile(vfs, resolvePath(cwd, fileArgs[0]))
      : stdin;
    const lines = text.split("\n");
    const slice = cmd === "head" ? lines.slice(0, count) : lines.slice(-count);
    return { output: slice.join("\n") };
  }

  if (cmd === "rm") {
    const recursive = args.includes("-r") || args.includes("-rf") || args.includes("-fr");
    const names = args.filter((a) => !a.startsWith("-"));
    if (!names[0]) return { output: "rm: missing operand" };
    try {
      let map = vfs;
      for (const name of names) {
        map = removePath(map, resolvePath(cwd, name), recursive);
      }
      store.setVfs(map);
      return { output: "" };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "cp" || cmd === "mv") {
    if (args.length < 2) return { output: `${cmd}: missing operand` };
    try {
      const src = resolvePath(cwd, args[0]);
      const dst = resolvePath(cwd, args[1]);
      const map = cmd === "cp" ? copyPath(vfs, src, dst) : movePath(vfs, src, dst);
      store.setVfs(map);
      return { output: "" };
    } catch (e) {
      return { output: String(e instanceof Error ? e.message : e) };
    }
  }

  if (cmd === "echo") {
    return { output: args.join(" ") };
  }

  if (cmd === "printf") {
    return { output: args.join(" ").replace(/\\n/g, "\n").replace(/\\t/g, "\t") };
  }

  if (cmd === "wc") {
    const text = args[0] ? readFile(vfs, resolvePath(cwd, args[0])) : stdin;
    const lines = text ? text.split("\n").length - (text.endsWith("\n") ? 1 : 0) : 0;
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const bytes = text.length;
    return { output: `${lines} ${words} ${bytes}` + (args[0] ? ` ${args[0]}` : "") };
  }

  if (cmd === "grep") {
    const pattern = args[0];
    if (!pattern) return { output: "grep: missing pattern" };
    const file = args[1];
    const text = file ? readFile(vfs, resolvePath(cwd, file)) : stdin;
    const re = new RegExp(pattern);
    const hits = text.split("\n").filter((l) => re.test(l));
    return { output: hits.join("\n") };
  }

  if (cmd === "find") {
    const q = (args[0] ?? "").toLowerCase();
    const hits = Object.keys(vfs).filter((p) => !q || p.toLowerCase().includes(q));
    return { output: hits.join("\n") };
  }

  if (cmd === "which") {
    const name = args[0] ?? "";
    if (EXECUTABLE_NAMES[name] || ["ls", "cd", "cat", "python", "node"].includes(name)) {
      return { output: `/usr/bin/${name}` };
    }
    return { output: "" };
  }

  if (cmd === "code" || cmd === "open" || cmd === "nano" || cmd === "vim" || cmd === "vi") {
    const file = args[0];
    if (!file) {
      store.setWorkspaceOpen(true);
      return { output: "", extra: { openWorkspace: true } };
    }
    const target = resolvePath(cwd, file);
    if (!exists(vfs, target)) {
      store.setVfs(writeFile(vfs, target, ""));
    }
    store.setOpenFilePath(target);
    store.setWorkspaceOpen(true);
    return { output: `opened ${target}`, extra: { openFile: target, openWorkspace: true } };
  }

  if (cmd === "run") {
    const lang = args[0];
    const code = args.slice(1).join(" ");
    if (!lang || !code) return { output: "uso: run <lenguaje> <código>" };
    const output = await executeCode({
      language: resolveLanguage(lang),
      files: [{ name: "main", content: code }],
      stdin,
    });
    return { output };
  }

  if (cmd === "python" || cmd === "python3" || cmd === "python2") {
    return runInterpreter("python", args, stdin, vfs, cwd);
  }
  if (cmd === "node" || cmd === "nodejs") {
    return runInterpreter("javascript", args, stdin, vfs, cwd);
  }
  if (cmd === "ts-node" || cmd === "tsx") {
    return runInterpreter("typescript", args, stdin, vfs, cwd);
  }

  if (EXECUTABLE_NAMES[cmd]) {
    return runInterpreter(EXECUTABLE_NAMES[cmd], args, stdin, vfs, cwd);
  }

  // Package managers — no persisten en el VFS virtual, orientar al usuario
  if (cmd === "npm") {
    const sub = args[0];
    if (sub === "install" || sub === "i" || sub === "add") {
      const pkgs = args.slice(1).join(", ") || "dependencias";
      return {
        output: `[DevAurora] npm no persiste en el workspace virtual.\nPara usar paquetes externos, usa execute_code con un lenguaje que los tenga incluidos, o pídele a la IA que importe desde CDN en el código.`,
      };
    }
    if (sub === "run") {
      const script = args[1];
      if (!script) return { output: "npm run: falta el nombre del script" };
      // intenta encontrar y ejecutar el script como js
      const pkgPath = resolvePath(cwd, "package.json");
      if (!isFile(vfs, pkgPath)) return { output: `npm run ${script}: no se encontró package.json` };
      try {
        const pkg = JSON.parse(readFile(vfs, pkgPath)) as { scripts?: Record<string, string> };
        const scriptCmd = pkg.scripts?.[script];
        if (!scriptCmd) return { output: `npm run ${script}: script no definido en package.json` };
        return runCommand(scriptCmd);
      } catch {
        return { output: "npm run: package.json inválido" };
      }
    }
    return { output: `npm ${args.join(" ")}: comando npm no soportado en este entorno` };
  }

  if (cmd === "pip" || cmd === "pip3") {
    const sub = args[0];
    if (sub === "install") {
      return {
        output: `[DevAurora] pip no persiste en el workspace virtual.\nPide a la IA que importe directamente — las librerías estándar de Python sí están disponibles.`,
      };
    }
    return { output: `pip ${args.join(" ")}: comando no soportado en este entorno` };
  }

  if (cmd === "cargo") {
    return { output: `[DevAurora] cargo no está disponible en el workspace virtual. Usa rustc directamente para compilar archivos .rs.` };
  }

  if (cmd.startsWith("./") || cmd.endsWith(".py") || cmd.endsWith(".js") || cmd.endsWith(".sh")) {
    const target = resolvePath(cwd, cmd);
    if (isFile(vfs, target)) {
      const lang = extLanguage(target) ?? "bash";
      const output = await executeCode({
        language: lang,
        files: vfsFilesFor(vfs, target).map((f, i) =>
          i === 0 ? { ...f, name: baseName(target) } : f,
        ),
        stdin,
        args,
      });
      return { output };
    }
  }

  if (!cmd) return { output: "" };
  return { output: `deva: command not found: ${cmd}` };
}

async function runInterpreter(
  language: string,
  args: string[],
  stdin: string,
  vfs: VfsMap,
  cwd: string,
): Promise<{ output: string }> {
  const cIndex = args.indexOf("-c");
  const eIndex = args.indexOf("-e");
  if (cIndex >= 0 && args[cIndex + 1]) {
    const output = await executeCode({
      language,
      files: [{ name: "main", content: args[cIndex + 1] }],
      stdin,
      args: args.slice(cIndex + 2),
    });
    return { output };
  }
  if (eIndex >= 0 && args[eIndex + 1]) {
    const output = await executeCode({
      language,
      files: [{ name: "main", content: args[eIndex + 1] }],
      stdin,
      args: args.slice(eIndex + 2),
    });
    return { output };
  }
  const fileArg = args.find((a) => !a.startsWith("-"));
  if (!fileArg) {
    return {
      output: `${language} ${language === "python" ? "3.12" : ""} — usa \`${language === "javascript" ? "node" : language} archivo\` o \`-c "código"\`. REPL interactivo no está montado; ejecuta un archivo.`,
    };
  }
  const target = resolvePath(cwd, fileArg);
  if (!isFile(vfs, target)) {
    return { output: `${fileArg}: No such file or directory` };
  }
  const rest = args.filter((a) => a !== fileArg && !a.startsWith("-"));
  const output = await executeCode({
    language,
    files: vfsFilesFor(vfs, target),
    stdin,
    args: rest,
  });
  return { output };
}

export async function runCommand(raw: string): Promise<CommandResult> {
  const line = raw.replace(/\r/g, "").trimEnd();
  if (!line.trim()) return { output: "" };

  try {
    const stages = splitPipes(line);
    let stdin = "";
    let last: CommandResult = { output: "" };
    for (let i = 0; i < stages.length; i++) {
      const { argv, redirect } = applyRedirect(tokenize(stages[i]));
      if (!argv[0]) continue;
      const result = await runArgv(argv, stdin);
      let output = result.output;
      if (redirect) {
        const store = useAppStore.getState();
        const path = resolvePath(store.cwd, redirect.path);
        const prev = redirect.append && exists(store.vfs, path) ? readFile(store.vfs, path) : "";
        store.setVfs(writeFile(store.vfs, path, prev + output + (output.endsWith("\n") ? "" : "\n")));
        output = "";
      }
      stdin = output;
      last = { output, ...result.extra };
    }
    return last;
  } catch (e) {
    return { output: String(e instanceof Error ? e.message : e) };
  }
}

export async function executeSnippet(language: string, code: string, stdin = ""): Promise<string> {
  return executeCode({
    language: resolveLanguage(language),
    files: [{ name: "main", content: code }],
    stdin,
  });
}

export { tokenize };
