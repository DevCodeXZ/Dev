-- ========================================
-- Path: Workspace..Animate
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v_u_1 = script.Parent
local v_u_2 = v_u_1:WaitForChild("Humanoid")
local v_u_3 = "Standing"
local v4, v5 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserNoUpdateOnLoop")
end)
local v_u_6 = v4 and v5
local v7, v8 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAnimateScaleRun")
end)
local v_u_9 = v7 and v8
local function v_u_10() -- name: getRigScale
	-- upvalues: (copy) v_u_9, (copy) v_u_1
	return not v_u_9 and 1 or v_u_1:GetScale()
end
local v_u_11 = script:FindFirstChild("ScaleDampeningPercent")
local v_u_12 = ""
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = 1
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = {}
local v_u_20 = {}
local v_u_21 = {
	["idle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507766666",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766951",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766388",
			["weight"] = 9
		}
	},
	["walk"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777826",
			["weight"] = 10
		}
	},
	["run"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767714",
			["weight"] = 10
		}
	},
	["swim"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507784897",
			["weight"] = 10
		}
	},
	["swimidle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507785072",
			["weight"] = 10
		}
	},
	["jump"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765000",
			["weight"] = 10
		}
	},
	["fall"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767968",
			["weight"] = 10
		}
	},
	["climb"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765644",
			["weight"] = 10
		}
	},
	["sit"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=2506281703",
			["weight"] = 10
		}
	},
	["toolnone"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507768375",
			["weight"] = 10
		}
	},
	["toolslash"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522635514",
			["weight"] = 10
		}
	},
	["toollunge"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522638767",
			["weight"] = 10
		}
	},
	["wave"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770239",
			["weight"] = 10
		}
	},
	["point"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770453",
			["weight"] = 10
		}
	},
	["dance"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507771019",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507771955",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507772104",
			["weight"] = 10
		}
	},
	["dance2"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507776043",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776720",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776879",
			["weight"] = 10
		}
	},
	["dance3"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777268",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777451",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777623",
			["weight"] = 10
		}
	},
	["laugh"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770818",
			["weight"] = 10
		}
	},
	["cheer"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770677",
			["weight"] = 10
		}
	}
}
local v_u_22 = {
	["wave"] = false,
	["point"] = false,
	["dance"] = true,
	["dance2"] = true,
	["dance3"] = true,
	["laugh"] = false,
	["cheer"] = false
}
math.randomseed(tick())
function findExistingAnimationInSet(p23, p24) -- name: findExistingAnimationInSet
	if p23 == nil or p24 == nil then
		return 0
	end
	for v25 = 1, p23.count do
		if p23[v25].anim.AnimationId == p24.AnimationId then
			return v25
		end
	end
	return 0
end
function configureAnimationSet(p_u_26, p_u_27) -- name: configureAnimationSet
	-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_2
	if v_u_20[p_u_26] ~= nil then
		for _, v28 in pairs(v_u_20[p_u_26].connections) do
			v28:disconnect()
		end
	end
	v_u_20[p_u_26] = {}
	v_u_20[p_u_26].count = 0
	v_u_20[p_u_26].totalWeight = 0
	v_u_20[p_u_26].connections = {}
	local v_u_29 = true
	local v30, _ = pcall(function()
		-- upvalues: (ref) v_u_29
		v_u_29 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)
	v_u_29 = not v30 and true or v_u_29
	local v31 = script:FindFirstChild(p_u_26)
	if v_u_29 and v31 ~= nil then
		local v32 = v_u_20[p_u_26].connections
		local v33 = v31.ChildAdded
		table.insert(v32, v33:connect(function(_)
			-- upvalues: (copy) p_u_26, (copy) p_u_27
			configureAnimationSet(p_u_26, p_u_27)
		end))
		local v34 = v_u_20[p_u_26].connections
		local v35 = v31.ChildRemoved
		table.insert(v34, v35:connect(function(_)
			-- upvalues: (copy) p_u_26, (copy) p_u_27
			configureAnimationSet(p_u_26, p_u_27)
		end))
		for _, v36 in pairs(v31:GetChildren()) do
			if v36:IsA("Animation") then
				local v37 = v36:FindFirstChild("Weight")
				local v38 = v37 == nil and 1 or v37.Value
				v_u_20[p_u_26].count = v_u_20[p_u_26].count + 1
				local v39 = v_u_20[p_u_26].count
				v_u_20[p_u_26][v39] = {}
				v_u_20[p_u_26][v39].anim = v36
				v_u_20[p_u_26][v39].weight = v38
				v_u_20[p_u_26].totalWeight = v_u_20[p_u_26].totalWeight + v_u_20[p_u_26][v39].weight
				local v40 = v_u_20[p_u_26].connections
				local v41 = v36.Changed
				table.insert(v40, v41:connect(function(_)
					-- upvalues: (copy) p_u_26, (copy) p_u_27
					configureAnimationSet(p_u_26, p_u_27)
				end))
				local v42 = v_u_20[p_u_26].connections
				local v43 = v36.ChildAdded
				table.insert(v42, v43:connect(function(_)
					-- upvalues: (copy) p_u_26, (copy) p_u_27
					configureAnimationSet(p_u_26, p_u_27)
				end))
				local v44 = v_u_20[p_u_26].connections
				local v45 = v36.ChildRemoved
				table.insert(v44, v45:connect(function(_)
					-- upvalues: (copy) p_u_26, (copy) p_u_27
					configureAnimationSet(p_u_26, p_u_27)
				end))
			end
		end
	end
	if v_u_20[p_u_26].count <= 0 then
		for v46, v47 in pairs(p_u_27) do
			v_u_20[p_u_26][v46] = {}
			v_u_20[p_u_26][v46].anim = Instance.new("Animation")
			v_u_20[p_u_26][v46].anim.Name = p_u_26
			v_u_20[p_u_26][v46].anim.AnimationId = v47.id
			v_u_20[p_u_26][v46].weight = v47.weight
			v_u_20[p_u_26].count = v_u_20[p_u_26].count + 1
			v_u_20[p_u_26].totalWeight = v_u_20[p_u_26].totalWeight + v47.weight
		end
	end
	for _, v48 in pairs(v_u_20) do
		for v49 = 1, v48.count do
			if v_u_19[v48[v49].anim.AnimationId] == nil then
				v_u_2:LoadAnimation(v48[v49].anim)
				v_u_19[v48[v49].anim.AnimationId] = true
			end
		end
	end
end
function configureAnimationSetOld(p_u_50, p_u_51) -- name: configureAnimationSetOld
	-- upvalues: (copy) v_u_20, (copy) v_u_2
	if v_u_20[p_u_50] ~= nil then
		for _, v52 in pairs(v_u_20[p_u_50].connections) do
			v52:disconnect()
		end
	end
	v_u_20[p_u_50] = {}
	v_u_20[p_u_50].count = 0
	v_u_20[p_u_50].totalWeight = 0
	v_u_20[p_u_50].connections = {}
	local v_u_53 = true
	local v54, _ = pcall(function()
		-- upvalues: (ref) v_u_53
		v_u_53 = game:GetService("StarterPlayer").AllowCustomAnimations
	end)
	v_u_53 = not v54 and true or v_u_53
	local v55 = script:FindFirstChild(p_u_50)
	if v_u_53 and v55 ~= nil then
		local v56 = v_u_20[p_u_50].connections
		local v57 = v55.ChildAdded
		table.insert(v56, v57:connect(function(_)
			-- upvalues: (copy) p_u_50, (copy) p_u_51
			configureAnimationSet(p_u_50, p_u_51)
		end))
		local v58 = v_u_20[p_u_50].connections
		local v59 = v55.ChildRemoved
		table.insert(v58, v59:connect(function(_)
			-- upvalues: (copy) p_u_50, (copy) p_u_51
			configureAnimationSet(p_u_50, p_u_51)
		end))
		local v60 = 1
		for _, v61 in pairs(v55:GetChildren()) do
			if v61:IsA("Animation") then
				local v62 = v_u_20[p_u_50].connections
				local v63 = v61.Changed
				table.insert(v62, v63:connect(function(_)
					-- upvalues: (copy) p_u_50, (copy) p_u_51
					configureAnimationSet(p_u_50, p_u_51)
				end))
				v_u_20[p_u_50][v60] = {}
				v_u_20[p_u_50][v60].anim = v61
				local v64 = v61:FindFirstChild("Weight")
				if v64 == nil then
					v_u_20[p_u_50][v60].weight = 1
				else
					v_u_20[p_u_50][v60].weight = v64.Value
				end
				v_u_20[p_u_50].count = v_u_20[p_u_50].count + 1
				v_u_20[p_u_50].totalWeight = v_u_20[p_u_50].totalWeight + v_u_20[p_u_50][v60].weight
				v60 = v60 + 1
			end
		end
	end
	if v_u_20[p_u_50].count <= 0 then
		for v65, v66 in pairs(p_u_51) do
			v_u_20[p_u_50][v65] = {}
			v_u_20[p_u_50][v65].anim = Instance.new("Animation")
			v_u_20[p_u_50][v65].anim.Name = p_u_50
			v_u_20[p_u_50][v65].anim.AnimationId = v66.id
			v_u_20[p_u_50][v65].weight = v66.weight
			v_u_20[p_u_50].count = v_u_20[p_u_50].count + 1
			v_u_20[p_u_50].totalWeight = v_u_20[p_u_50].totalWeight + v66.weight
		end
	end
	for _, v67 in pairs(v_u_20) do
		for v68 = 1, v67.count do
			v_u_2:LoadAnimation(v67[v68].anim)
		end
	end
end
function scriptChildModified(p69) -- name: scriptChildModified
	-- upvalues: (copy) v_u_21
	local v70 = v_u_21[p69.Name]
	if v70 ~= nil then
		configureAnimationSet(p69.Name, v70)
	end
end
script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local v71
if v_u_2 then
	v71 = v_u_2:FindFirstChildOfClass("Animator")
else
	v71 = nil
end
if v71 then
	local v72 = v71:GetPlayingAnimationTracks()
	for _, v73 in ipairs(v72) do
		v73:Stop(0)
		v73:Destroy()
	end
end
for v74, v75 in pairs(v_u_21) do
	configureAnimationSet(v74, v75)
end
local v_u_76 = "None"
local v_u_77 = 0
local v_u_78 = 0
local v_u_79 = false
function stopAllAnimations() -- name: stopAllAnimations
	-- upvalues: (ref) v_u_12, (copy) v_u_22, (ref) v_u_79, (ref) v_u_13, (ref) v_u_15, (ref) v_u_14, (ref) v_u_18, (ref) v_u_17
	local v80 = v_u_12
	local v81 = v_u_22[v80] ~= nil and v_u_22[v80] == false and "idle" or v80
	if v_u_79 then
		v81 = "idle"
		v_u_79 = false
	end
	v_u_12 = ""
	v_u_13 = nil
	if v_u_15 ~= nil then
		v_u_15:disconnect()
	end
	if v_u_14 ~= nil then
		v_u_14:Stop()
		v_u_14:Destroy()
		v_u_14 = nil
	end
	if v_u_18 ~= nil then
		v_u_18:disconnect()
	end
	if v_u_17 ~= nil then
		v_u_17:Stop()
		v_u_17:Destroy()
		v_u_17 = nil
	end
	return v81
end
function getHeightScale() -- name: getHeightScale
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (ref) v_u_11
	if not v_u_2 then
		return v_u_10()
	end
	if not v_u_2.AutomaticScalingEnabled then
		return v_u_10()
	end
	local v82 = v_u_2.HipHeight / 2
	if v_u_11 == nil then
		v_u_11 = script:FindFirstChild("ScaleDampeningPercent")
	end
	if v_u_11 ~= nil then
		v82 = 1 + (v_u_2.HipHeight - 2) * v_u_11.Value / 2
	end
	return v82
end
local function v_u_88(p83) -- name: setRunSpeed
	-- upvalues: (ref) v_u_14, (ref) v_u_17
	local v84 = p83 * 1.25 / getHeightScale()
	local v85 = 0.0001
	local v86 = 0.0001
	local v87 = 1
	if v84 <= 0.5 then
		v87 = v84 / 0.5
		v85 = 1
	elseif v84 < 1 then
		v86 = (v84 - 0.5) / 0.5
		v85 = 1 - v86
	else
		v87 = v84 / 1
		v86 = 1
	end
	v_u_14:AdjustWeight(v85)
	v_u_17:AdjustWeight(v86)
	v_u_14:AdjustSpeed(v87)
	v_u_17:AdjustSpeed(v87)
end
function setAnimationSpeed(p89) -- name: setAnimationSpeed
	-- upvalues: (ref) v_u_12, (copy) v_u_88, (ref) v_u_16, (ref) v_u_14
	if v_u_12 == "walk" then
		v_u_88(p89)
	elseif p89 ~= v_u_16 then
		v_u_16 = p89
		v_u_14:AdjustSpeed(v_u_16)
	end
end
function keyFrameReachedFunc(p90) -- name: keyFrameReachedFunc
	-- upvalues: (ref) v_u_12, (copy) v_u_6, (ref) v_u_17, (ref) v_u_14, (copy) v_u_22, (ref) v_u_79, (ref) v_u_16, (copy) v_u_2
	if p90 == "End" then
		if v_u_12 == "walk" then
			if v_u_6 ~= true then
				v_u_17.TimePosition = 0
				v_u_14.TimePosition = 0
				return
			end
			if v_u_17.Looped ~= true then
				v_u_17.TimePosition = 0
			end
			if v_u_14.Looped ~= true then
				v_u_14.TimePosition = 0
				return
			end
		else
			local v91 = v_u_12
			local v92 = v_u_22[v91] ~= nil and v_u_22[v91] == false and "idle" or v91
			if v_u_79 then
				if v_u_14.Looped then
					return
				end
				v92 = "idle"
				v_u_79 = false
			end
			local v93 = v_u_16
			playAnimation(v92, 0.15, v_u_2)
			setAnimationSpeed(v93)
		end
	end
end
function rollAnimation(p94) -- name: rollAnimation
	-- upvalues: (copy) v_u_20
	local v95 = math.random(1, v_u_20[p94].totalWeight)
	local v96 = 1
	while v_u_20[p94][v96].weight < v95 do
		v95 = v95 - v_u_20[p94][v96].weight
		v96 = v96 + 1
	end
	return v96
end
local function v_u_102(p97, p98, p99, p100) -- name: switchToAnim
	-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_17, (copy) v_u_6, (ref) v_u_16, (ref) v_u_12, (ref) v_u_15, (copy) v_u_20, (ref) v_u_18
	if p97 ~= v_u_13 then
		if v_u_14 ~= nil then
			v_u_14:Stop(p99)
			v_u_14:Destroy()
		end
		if v_u_17 ~= nil then
			v_u_17:Stop(p99)
			v_u_17:Destroy()
			if v_u_6 == true then
				v_u_17 = nil
			end
		end
		v_u_16 = 1
		v_u_14 = p100:LoadAnimation(p97)
		v_u_14.Priority = Enum.AnimationPriority.Core
		v_u_14:Play(p99)
		v_u_12 = p98
		v_u_13 = p97
		if v_u_15 ~= nil then
			v_u_15:disconnect()
		end
		v_u_15 = v_u_14.KeyframeReached:connect(keyFrameReachedFunc)
		if p98 == "walk" then
			local v101 = rollAnimation("run")
			v_u_17 = p100:LoadAnimation(v_u_20.run[v101].anim)
			v_u_17.Priority = Enum.AnimationPriority.Core
			v_u_17:Play(p99)
			if v_u_18 ~= nil then
				v_u_18:disconnect()
			end
			v_u_18 = v_u_17.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end
function playAnimation(p103, p104, p105) -- name: playAnimation
	-- upvalues: (copy) v_u_20, (copy) v_u_102, (ref) v_u_79
	local v106 = rollAnimation(p103)
	v_u_102(v_u_20[p103][v106].anim, p103, p104, p105)
	v_u_79 = false
end
function playEmote(p107, p108, p109) -- name: playEmote
	-- upvalues: (copy) v_u_102, (ref) v_u_79
	v_u_102(p107, p107.Name, p108, p109)
	v_u_79 = true
end
local v_u_110 = ""
local v_u_111 = nil
local v_u_112 = nil
local v_u_113 = nil
function toolKeyFrameReachedFunc(p114) -- name: toolKeyFrameReachedFunc
	-- upvalues: (ref) v_u_110, (copy) v_u_2
	if p114 == "End" then
		playToolAnimation(v_u_110, 0, v_u_2)
	end
end
function playToolAnimation(p115, p116, p117, p118) -- name: playToolAnimation
	-- upvalues: (copy) v_u_20, (ref) v_u_112, (ref) v_u_111, (ref) v_u_110, (ref) v_u_113
	local v119 = rollAnimation(p115)
	local v120 = v_u_20[p115][v119].anim
	if v_u_112 ~= v120 then
		if v_u_111 ~= nil then
			v_u_111:Stop()
			v_u_111:Destroy()
			p116 = 0
		end
		v_u_111 = p117:LoadAnimation(v120)
		if p118 then
			v_u_111.Priority = p118
		end
		v_u_111:Play(p116)
		v_u_110 = p115
		v_u_112 = v120
		v_u_113 = v_u_111.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end
function stopToolAnimations() -- name: stopToolAnimations
	-- upvalues: (ref) v_u_110, (ref) v_u_113, (ref) v_u_112, (ref) v_u_111
	local v121 = v_u_110
	if v_u_113 ~= nil then
		v_u_113:disconnect()
	end
	v_u_110 = ""
	v_u_112 = nil
	if v_u_111 ~= nil then
		v_u_111:Stop()
		v_u_111:Destroy()
		v_u_111 = nil
	end
	return v121
end
function onRunning(p122) -- name: onRunning
	-- upvalues: (copy) v_u_9, (ref) v_u_79, (copy) v_u_2, (ref) v_u_3, (copy) v_u_22, (ref) v_u_12
	local v123 = not v_u_9 and 1 or getHeightScale()
	local v124 = v_u_79
	if v124 then
		v124 = v_u_2.MoveDirection == Vector3.new(0, 0, 0)
	end
	if (v124 and (v_u_2.WalkSpeed / v123 or 0.75) or 0.75) * v123 < p122 then
		playAnimation("walk", 0.2, v_u_2)
		setAnimationSpeed(p122 / 16)
		v_u_3 = "Running"
	elseif v_u_22[v_u_12] == nil and not v_u_79 then
		playAnimation("idle", 0.2, v_u_2)
		v_u_3 = "Standing"
	end
end
function onDied() -- name: onDied
	-- upvalues: (ref) v_u_3
	v_u_3 = "Dead"
end
function onJumping() -- name: onJumping
	-- upvalues: (copy) v_u_2, (ref) v_u_78, (ref) v_u_3
	playAnimation("jump", 0.1, v_u_2)
	v_u_78 = 0.31
	v_u_3 = "Jumping"
end
function onClimbing(p125) -- name: onClimbing
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (ref) v_u_3
	if v_u_9 then
		p125 = p125 / getHeightScale()
	end
	playAnimation("climb", 0.1, v_u_2)
	setAnimationSpeed(p125 / 5)
	v_u_3 = "Climbing"
end
function onGettingUp() -- name: onGettingUp
	-- upvalues: (ref) v_u_3
	v_u_3 = "GettingUp"
end
function onFreeFall() -- name: onFreeFall
	-- upvalues: (ref) v_u_78, (copy) v_u_2, (ref) v_u_3
	if v_u_78 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	end
	v_u_3 = "FreeFall"
end
function onFallingDown() -- name: onFallingDown
	-- upvalues: (ref) v_u_3
	v_u_3 = "FallingDown"
end
function onSeated() -- name: onSeated
	-- upvalues: (ref) v_u_3
	v_u_3 = "Seated"
end
function onPlatformStanding() -- name: onPlatformStanding
	-- upvalues: (ref) v_u_3
	v_u_3 = "PlatformStanding"
end
function onSwimming(p126) -- name: onSwimming
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (ref) v_u_3
	if v_u_9 then
		p126 = p126 / getHeightScale()
	end
	if p126 > 1 then
		playAnimation("swim", 0.4, v_u_2)
		setAnimationSpeed(p126 / 10)
		v_u_3 = "Swimming"
	else
		playAnimation("swimidle", 0.4, v_u_2)
		v_u_3 = "Standing"
	end
end
function animateTool() -- name: animateTool
	-- upvalues: (ref) v_u_76, (copy) v_u_2
	if v_u_76 == "None" then
		playToolAnimation("toolnone", 0.1, v_u_2, Enum.AnimationPriority.Idle)
		return
	elseif v_u_76 == "Slash" then
		playToolAnimation("toolslash", 0, v_u_2, Enum.AnimationPriority.Action)
		return
	elseif v_u_76 == "Lunge" then
		playToolAnimation("toollunge", 0, v_u_2, Enum.AnimationPriority.Action)
	end
end
function getToolAnim(p127) -- name: getToolAnim
	for _, v128 in ipairs(p127:GetChildren()) do
		if v128.Name == "toolanim" and v128.className == "StringValue" then
			return v128
		end
	end
	return nil
end
local v_u_129 = 0
function stepAnimate(p130) -- name: stepAnimate
	-- upvalues: (ref) v_u_129, (ref) v_u_78, (ref) v_u_3, (copy) v_u_2, (copy) v_u_1, (ref) v_u_76, (ref) v_u_77, (ref) v_u_112
	local v131 = p130 - v_u_129
	v_u_129 = p130
	if v_u_78 > 0 then
		v_u_78 = v_u_78 - v131
	end
	if v_u_3 == "FreeFall" and v_u_78 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	else
		if v_u_3 == "Seated" then
			playAnimation("sit", 0.5, v_u_2)
			return
		end
		if v_u_3 == "Running" then
			playAnimation("walk", 0.2, v_u_2)
		elseif v_u_3 == "Dead" or (v_u_3 == "GettingUp" or (v_u_3 == "FallingDown" or (v_u_3 == "Seated" or v_u_3 == "PlatformStanding"))) then
			stopAllAnimations()
		end
	end
	local v132 = v_u_1:FindFirstChildOfClass("Tool")
	if v132 and v132:FindFirstChild("Handle") then
		local v133 = getToolAnim(v132)
		if v133 then
			v_u_76 = v133.Value
			v133.Parent = nil
			v_u_77 = p130 + 0.3
		end
		if v_u_77 < p130 then
			v_u_77 = 0
			v_u_76 = "None"
		end
		animateTool()
	else
		stopToolAnimations()
		v_u_76 = "None"
		v_u_112 = nil
		v_u_77 = 0
	end
end
v_u_2.Died:connect(onDied)
v_u_2.Running:connect(onRunning)
v_u_2.Jumping:connect(onJumping)
v_u_2.Climbing:connect(onClimbing)
v_u_2.GettingUp:connect(onGettingUp)
v_u_2.FreeFalling:connect(onFreeFall)
v_u_2.FallingDown:connect(onFallingDown)
v_u_2.Seated:connect(onSeated)
v_u_2.PlatformStanding:connect(onPlatformStanding)
v_u_2.Swimming:connect(onSwimming)
game:GetService("Players").LocalPlayer.Chatted:connect(function(p134)
	-- upvalues: (ref) v_u_3, (copy) v_u_22, (copy) v_u_2
	local v135 = ""
	if string.sub(p134, 1, 3) == "/e " then
		v135 = string.sub(p134, 4)
	elseif string.sub(p134, 1, 7) == "/emote " then
		v135 = string.sub(p134, 8)
	end
	if v_u_3 == "Standing" and v_u_22[v135] ~= nil then
		playAnimation(v135, 0.1, v_u_2)
	end
end)
script:WaitForChild("PlayEmote").OnInvoke = function(p136)
	-- upvalues: (ref) v_u_3, (copy) v_u_22, (copy) v_u_2, (ref) v_u_14
	if v_u_3 == "Standing" then
		if v_u_22[p136] ~= nil then
			playAnimation(p136, 0.1, v_u_2)
			return true, v_u_14
		end
		if typeof(p136) ~= "Instance" or not p136:IsA("Animation") then
			return false
		end
		playEmote(p136, 0.1, v_u_2)
		return true, v_u_14
	end
end
if v_u_1.Parent ~= nil then
	playAnimation("idle", 0.1, v_u_2)
	local _ = "Standing"
end
while v_u_1.Parent ~= nil do
	local _, v137 = wait(0.1)
	stepAnimate(v137)
end