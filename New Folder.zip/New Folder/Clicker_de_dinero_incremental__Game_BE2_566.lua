-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.Clicker.MoneyClicker.CyclePower.CycleStuck.BE2
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v_u_1 = game.ReplicatedStorage.CEvents.PlaySound
local _ = script.Parent.Size
local _ = script.Parent.Position
script.Parent.Button.MouseEnter:Connect(function()
	local v2 = script.Parent
	v2.ZIndex = v2.ZIndex + 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = true
	end
	script.Parent.ButtonEffectF.Visible = true
end)
script.Parent.Button.MouseLeave:Connect(function()
	local v3 = script.Parent
	v3.ZIndex = v3.ZIndex - 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = false
	end
	script.Parent.ButtonEffectF.Visible = false
end)
script.Parent.Button.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_1
	v_u_1:Fire("Click")
end)