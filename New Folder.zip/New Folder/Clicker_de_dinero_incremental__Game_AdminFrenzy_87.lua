-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.InterfaceScript.AdminFrenzy
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v1 = game.ReplicatedStorage.AdminFrenzy
local v2 = game.ReplicatedStorage.CEvents
local v_u_3 = script.Parent.Parent.Currencies.BonusWindow
local v4 = script.Parent.Parent.AdminEventInfo
v2.AdminWindow.OnClientEvent:Connect(function(p5, p6)
	-- upvalues: (copy) v_u_3
	v_u_3.Visible = true
	v_u_3:TweenPosition(UDim2.new(0.5, 0, 2.5, 0), "In", "Linear", 0.2, true)
	v_u_3.Bonus1.Text = p5
	v_u_3.Bonus2.Text = p6
	task.wait(7)
	v_u_3:TweenPosition(UDim2.new(0.5, 0, -3.5, 0), "In", "Linear", 0.2, true)
	v_u_3.Visible = false
end)
while true do
	local v7 = v1.Frenzy.Value
	script.Parent.Parent.AdminEvent.Visible = v7
	script.Parent.Parent.Currencies.AdminNextEvent.Visible = v7
	if v7 then
		local v8 = v1.NextFrenzy.FrenzyLeft.Value
		local v9 = v8 / 60
		local v10 = math.floor(v9)
		local v11 = v8 % 60
		script.Parent.Parent.Currencies.AdminNextEvent.Text = "ADMIN EVENT " .. v1.NextEvent.Value
		v4.TimeLeft.Text = string.format("%02d:%02d", v10, v11)
		v4.Title.Text = "TIME LEFT"
	else
		local v12 = v1.NextFrenzy.Value
		local v13 = v12 / 86400
		local v14 = math.floor(v13)
		local v15 = v12 / 3600
		local v16 = math.floor(v15) % 24
		local v17 = v12 / 60
		local v18 = math.floor(v17) % 60
		local v19 = v12 % 60
		v4.TimeLeft.Text = string.format("%d:%02d:%02d:%02d", v14, v16, v18, v19)
		v4.Title.Text = "ADMIN ABUSE IN"
	end
	task.wait(1)
end