-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.InterfaceScript.AutoclickMoney
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v1 = game.ReplicatedStorage.Events.Upgrade
wait(2)
local v2 = game:GetService("Players").LocalPlayer:WaitForChild("Stats")
while true do
	if v2.ResearchUpgrade9.Value ~= 0 and v2.MoneyClickerUpgradeAutomation.Value == 0 then
		for v3 = 1, v2.ResearchUpgrade9.Value do
			if v2.ResearchUpgrade10.Value == 5 then
				v1:FireServer(v3, true, true)
			else
				for _ = 1, v2.ResearchUpgrade10.Value + 1 do
					v1:FireServer(v3, false, true)
					wait()
				end
			end
		end
	end
	wait(1)
end