import { getModel } from "@/lib/models";
import { useAppStore } from "@/lib/store";

// Un solo modelo: mostramos el nombre estático sin dropdown
export function ModelMenu() {
  const modelId = useAppStore((s) => s.modelId);
  const current = getModel(modelId);

  return (
    <span className="inline-flex h-10 items-center rounded-lg px-3 text-sm font-medium text-fg">
      {current.name}
      <span className="ml-2 rounded-full bg-chip px-2 py-0.5 text-[10px] font-medium text-muted">
        {current.tag}
      </span>
    </span>
  );
}
