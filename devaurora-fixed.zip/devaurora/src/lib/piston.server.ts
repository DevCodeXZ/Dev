import { spawn } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { resolveLanguage } from "./languages";

const JUDGE0 = "https://ce.judge0.com";

const JUDGE0_IDS: Record<string, number> = {
  python: 109,
  python2: 70,
  javascript: 102,
  typescript: 101,
  bash: 46,
  c: 103,
  "c++": 105,
  csharp: 51,
  go: 107,
  rust: 108,
  java: 91,
  ruby: 72,
  php: 98,
  lua: 64,
  kotlin: 111,
  swift: 83,
  rscript: 99,
  haskell: 61,
  scala: 112,
  perl: 85,
  dart: 90,
  elixir: 57,
  sqlite3: 82,
  fortran: 59,
  cobol: 77,
  lisp: 55,
  clojure: 86,
  erlang: 58,
  d: 56,
  pascal: 67,
  groovy: 88,
  ocaml: 65,
  nasm: 45,
  basic: 47,
  text: 43,
};

export type ExecuteInput = {
  language: string;
  files: { name: string; content: string }[];
  stdin?: string;
  args?: string[];
};

export type ExecuteResult = {
  ok: boolean;
  language: string;
  version: string;
  stdout: string;
  stderr: string;
  code: number | null;
  timedOut: boolean;
  error?: string;
};

function mainFile(files: { name: string; content: string }[], language: string) {
  const prefer: Record<string, string[]> = {
    python: [".py"],
    javascript: [".js", ".mjs", ".cjs"],
    typescript: [".ts"],
    bash: [".sh"],
    c: [".c"],
    "c++": [".cpp", ".cc", ".cxx"],
    java: [".java"],
    rust: [".rs"],
    go: [".go"],
    ruby: [".rb"],
    php: [".php"],
  };
  const exts = prefer[language] ?? [];
  return (
    files.find((f) => exts.some((e) => f.name.endsWith(e))) ??
    files[0] ?? { name: "main", content: "" }
  );
}

function runProcess(
  cmd: string,
  args: string[],
  opts: { cwd: string; stdin?: string; timeoutMs?: number },
): Promise<{ stdout: string; stderr: string; code: number | null; timedOut: boolean }> {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, {
      cwd: opts.cwd,
      env: { ...process.env, PATH: process.env.PATH ?? "/usr/bin:/usr/local/bin" },
    });
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const t = setTimeout(() => {
      timedOut = true;
      child.kill("SIGKILL");
    }, opts.timeoutMs ?? 8000);
    child.stdout.on("data", (d: Buffer) => {
      stdout += d.toString();
      if (stdout.length > 80_000) stdout = stdout.slice(0, 80_000);
    });
    child.stderr.on("data", (d: Buffer) => {
      stderr += d.toString();
      if (stderr.length > 80_000) stderr = stderr.slice(0, 80_000);
    });
    if (opts.stdin) child.stdin.write(opts.stdin);
    child.stdin.end();
    child.on("close", (code) => {
      clearTimeout(t);
      resolve({ stdout, stderr, code, timedOut });
    });
    child.on("error", (err) => {
      clearTimeout(t);
      resolve({ stdout, stderr: stderr + err.message, code: 1, timedOut });
    });
  });
}

async function executeLocal(input: ExecuteInput, language: string): Promise<ExecuteResult | null> {
  const file = mainFile(input.files, language);
  const dir = await mkdtemp(join(tmpdir(), "deva-"));
  try {
    for (const f of input.files) {
      const safe = f.name.replaceAll("..", "_").replace(/^\/+/, "");
      const path = join(dir, safe);
      const parent = path.slice(0, path.lastIndexOf("/"));
      if (parent && parent !== dir) {
        await writeFile(join(dir, safe), f.content).catch(async () => {
          const { mkdir } = await import("node:fs/promises");
          await mkdir(parent, { recursive: true });
          await writeFile(path, f.content);
        });
      } else {
        await writeFile(path, f.content);
      }
    }
    const args = input.args ?? [];
    let result: { stdout: string; stderr: string; code: number | null; timedOut: boolean } | null =
      null;
    if (language === "python") {
      result = await runProcess("python3", [file.name, ...args], {
        cwd: dir,
        stdin: input.stdin,
      });
    } else if (language === "javascript") {
      result = await runProcess("node", [file.name, ...args], { cwd: dir, stdin: input.stdin });
    } else if (language === "bash") {
      result = await runProcess("bash", [file.name, ...args], { cwd: dir, stdin: input.stdin });
    } else if (language === "perl") {
      result = await runProcess("perl", [file.name, ...args], { cwd: dir, stdin: input.stdin });
    } else if (language === "c") {
      const compiled = await runProcess("gcc", ["-O0", "-o", "a.out", file.name], { cwd: dir });
      if (compiled.code !== 0) {
        return {
          ok: false,
          language,
          version: "gcc",
          stdout: compiled.stdout,
          stderr: compiled.stderr,
          code: compiled.code,
          timedOut: compiled.timedOut,
        };
      }
      result = await runProcess(join(dir, "a.out"), args, { cwd: dir, stdin: input.stdin });
    } else if (language === "c++") {
      const compiled = await runProcess("g++", ["-O0", "-o", "a.out", file.name], { cwd: dir });
      if (compiled.code !== 0) {
        return {
          ok: false,
          language,
          version: "g++",
          stdout: compiled.stdout,
          stderr: compiled.stderr,
          code: compiled.code,
          timedOut: compiled.timedOut,
        };
      }
      result = await runProcess(join(dir, "a.out"), args, { cwd: dir, stdin: input.stdin });
    } else if (language === "java") {
      const compiled = await runProcess("javac", [file.name], { cwd: dir });
      if (compiled.code !== 0) {
        return {
          ok: false,
          language,
          version: "javac",
          stdout: compiled.stdout,
          stderr: compiled.stderr,
          code: compiled.code,
          timedOut: compiled.timedOut,
        };
      }
      const cls = file.name.replace(/\.java$/, "");
      result = await runProcess("java", [cls, ...args], { cwd: dir, stdin: input.stdin });
    } else {
      return null;
    }
    if (!result) return null;
    return {
      ok: result.code === 0 && !result.timedOut,
      language,
      version: "local",
      stdout: result.stdout,
      stderr: result.stderr,
      code: result.code,
      timedOut: result.timedOut,
    };
  } catch {
    return null;
  } finally {
    await rm(dir, { recursive: true, force: true }).catch(() => undefined);
  }
}

async function executeJudge0(input: ExecuteInput, language: string): Promise<ExecuteResult> {
  const id = JUDGE0_IDS[language];
  if (!id) {
    return {
      ok: false,
      language,
      version: "",
      stdout: "",
      stderr: "",
      code: null,
      timedOut: false,
      error: `Lenguaje no soportado: ${language}`,
    };
  }
  const file = mainFile(input.files, language);
  const res = await fetch(`${JUDGE0}/submissions?base64_encoded=false&wait=true`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      source_code: file.content,
      language_id: id,
      stdin: input.stdin ?? "",
      command_line_arguments: (input.args ?? []).join(" "),
      cpu_time_limit: 8,
      wall_time_limit: 10,
      memory_limit: 128000,
    }),
  });
  if (!res.ok) {
    const text = await res.text();
    return {
      ok: false,
      language,
      version: "judge0",
      stdout: "",
      stderr: text.slice(0, 4000),
      code: null,
      timedOut: false,
      error: `Error del ejecutor (${res.status})`,
    };
  }
  const body = (await res.json()) as {
    stdout?: string | null;
    stderr?: string | null;
    compile_output?: string | null;
    message?: string | null;
    status?: { id?: number; description?: string };
    time?: string | null;
  };
  const stdout = (body.stdout ?? "").slice(0, 80_000);
  const stderr = ((body.compile_output ?? "") + (body.stderr ?? "") + (body.message ?? "")).slice(
    0,
    80_000,
  );
  const statusId = body.status?.id ?? 0;
  const timedOut = statusId === 5;
  const ok = statusId === 3;
  return {
    ok,
    language,
    version: "judge0",
    stdout,
    stderr,
    code: ok ? 0 : statusId,
    timedOut,
    error: ok ? undefined : body.status?.description,
  };
}

export async function executeOnPiston(input: ExecuteInput): Promise<ExecuteResult> {
  const language = resolveLanguage(input.language);
  const files = input.files.length ? input.files.slice(0, 30) : [{ name: "main", content: "" }];
  const payload = { ...input, files };

  const localLangs = new Set(["python", "javascript", "bash", "perl", "c", "c++", "java"]);
  if (localLangs.has(language)) {
    const local = await executeLocal(payload, language);
    if (local && (local.ok || local.stderr || local.stdout)) return local;
  }

  return executeJudge0(payload, language);
}

export function formatExecute(result: ExecuteResult): string {
  const parts: string[] = [];
  if (result.error) parts.push(result.error);
  if (result.stdout) parts.push(result.stdout.replace(/\n$/, ""));
  if (result.stderr) parts.push(result.stderr.replace(/\n$/, ""));
  if (result.timedOut) parts.push("[tiempo agotado]");
  if (!parts.length) {
    parts.push(result.ok ? "" : `proceso terminó con código ${result.code ?? 1}`);
  }
  return parts.filter(Boolean).join("\n");
}
