import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronRight, Trash2, X } from "lucide-react";
import { runCommand } from "@/lib/shell";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/cn";

export function TerminalPane({ onClose }: { onClose: () => void }) {
  const lines = useAppStore((s) => s.terminalLines);
  const cwd = useAppStore((s) => s.cwd);
  const history = useAppStore((s) => s.commandHistory);
  const pushTerminal = useAppStore((s) => s.pushTerminal);
  const pushHistory = useAppStore((s) => s.pushHistory);
  const clearTerminal = useAppStore((s) => s.clearTerminal);
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [histIdx, setHistIdx] = useState<number | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);

  const shortCwd = useMemo(() => {
    if (cwd === "/workspace") return "~/workspace";
    if (cwd.startsWith("/workspace/")) return "~/" + cwd.slice(1);
    return cwd;
  }, [cwd]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
  }, [lines.length, busy]);

  const run = async (raw: string) => {
    const cmd = raw.trimEnd();
    if (!cmd.trim()) return;
    pushHistory(cmd);
    pushTerminal({ kind: "in", text: `deva@aurora:${shortCwd}$ ${cmd}` });
    setValue("");
    setHistIdx(null);
    setBusy(true);
    try {
      const result = await runCommand(cmd);
      if (result.clear) clearTerminal();
      else if (result.output) pushTerminal({ kind: "out", text: result.output });
      if (result.closeTerminal) onClose();
    } catch (e) {
      pushTerminal({ kind: "err", text: e instanceof Error ? e.message : "error" });
    } finally {
      setBusy(false);
      input.current?.focus();
    }
  };

  const complete = () => {
    const vfs = useAppStore.getState().vfs;
    const parts = value.split(/\s+/);
    const last = parts[parts.length - 1] ?? "";
    const names = Object.keys(vfs)
      .map((p) => p.split("/").pop() ?? "")
      .filter((n) => n && n.startsWith(last));
    const unique = [...new Set(names)];
    if (unique.length === 1) {
      parts[parts.length - 1] = unique[0];
      setValue(parts.join(" ") + " ");
    }
  };

  return (
    <div className="flex h-full min-h-0 flex-col bg-term text-term-fg">
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-border bg-sidebar px-2">
        <span className="flex items-center gap-1 px-1 text-xs font-medium text-muted">
          <ChevronRight className="size-3.5 text-prompt" />
          Terminal
        </span>
        <span className="truncate font-mono text-[11px] text-dim">{shortCwd}</span>
        <div className="ml-auto flex items-center">
          <button
            type="button"
            className="flex size-8 items-center justify-center rounded-md text-dim hover:bg-hover hover:text-fg"
            onClick={() => clearTerminal()}
            aria-label="Limpiar"
          >
            <Trash2 className="size-3.5" />
          </button>
          <button
            type="button"
            className="flex size-8 items-center justify-center rounded-md text-dim hover:bg-hover hover:text-fg"
            onClick={onClose}
            aria-label="Cerrar terminal"
          >
            <X className="size-3.5" />
          </button>
        </div>
      </div>
      <div
        ref={scroller}
        className="min-h-0 flex-1 overflow-auto px-3 py-2 font-mono text-[12.5px] leading-relaxed"
        onClick={() => input.current?.focus()}
      >
        {lines.map((l) => (
          <pre
            key={l.id}
            className={cn(
              "whitespace-pre-wrap break-words",
              l.kind === "in" && "text-prompt",
              l.kind === "err" && "text-danger",
              l.kind === "sys" && "text-dim",
            )}
          >
            {l.text}
          </pre>
        ))}
        <form
          className="flex items-center gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!busy) void run(value);
          }}
        >
          <span className="shrink-0 text-prompt">deva@aurora:{shortCwd}$</span>
          <input
            ref={input}
            value={value}
            disabled={busy}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Tab") {
                e.preventDefault();
                complete();
              } else if (e.key === "l" && e.ctrlKey) {
                e.preventDefault();
                clearTerminal();
              } else if (e.key === "c" && e.ctrlKey) {
                setValue("");
              } else if (e.key === "ArrowUp") {
                e.preventDefault();
                if (!history.length) return;
                const next = histIdx === null ? history.length - 1 : Math.max(0, histIdx - 1);
                setHistIdx(next);
                setValue(history[next] ?? "");
              } else if (e.key === "ArrowDown") {
                e.preventDefault();
                if (histIdx === null) return;
                const next = histIdx + 1;
                if (next >= history.length) {
                  setHistIdx(null);
                  setValue("");
                } else {
                  setHistIdx(next);
                  setValue(history[next] ?? "");
                }
              }
            }}
            className="min-w-0 flex-1 bg-transparent outline-none"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            aria-label="Comando"
          />
          {busy && <span className="text-dim">…</span>}
        </form>
      </div>
    </div>
  );
}
