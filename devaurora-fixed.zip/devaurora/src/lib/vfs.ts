import type { VfsEntry, VfsMap } from "./types";

export const ROOT = "/";
export const WORKSPACE = "/workspace";

export function now(): number {
  return Date.now();
}

export function normalizePath(path: string): string {
  const parts = path.replaceAll("\\", "/").split("/");
  const stack: string[] = [];
  for (const part of parts) {
    if (!part || part === ".") continue;
    if (part === "..") {
      stack.pop();
      continue;
    }
    stack.push(part);
  }
  return "/" + stack.join("/");
}

export function resolvePath(cwd: string, path: string): string {
  const trimmed = path.trim() || ".";
  if (trimmed.startsWith("/")) return normalizePath(trimmed);
  if (trimmed.startsWith("~")) {
    return normalizePath(WORKSPACE + trimmed.slice(1));
  }
  return normalizePath(cwd + "/" + trimmed);
}

export function parentPath(path: string): string {
  const n = normalizePath(path);
  if (n === "/") return "/";
  const i = n.lastIndexOf("/");
  return i <= 0 ? "/" : n.slice(0, i);
}

export function baseName(path: string): string {
  const n = normalizePath(path);
  if (n === "/") return "/";
  return n.slice(n.lastIndexOf("/") + 1);
}

export function joinPath(a: string, b: string): string {
  return normalizePath(a + "/" + b);
}

export function seedVfs(): VfsMap {
  const t = now();
  const files: VfsMap = {
    "/": { type: "dir", updatedAt: t },
    "/workspace": { type: "dir", updatedAt: t },
    "/workspace/examples": { type: "dir", updatedAt: t },
    "/workspace/src": { type: "dir", updatedAt: t },
    "/workspace/README.md": {
      type: "file",
      updatedAt: t,
      content: `# DevAurora Workspace

Este es tu espacio de trabajo. La terminal entiende comandos Unix
y puede ejecutar Python, JavaScript, TypeScript, C, C++, Go, Rust,
Java, Ruby, PHP, Bash y decenas de lenguajes más.

Prueba:

    python examples/hello.py
    node examples/hello.js
    ls -la
    help
`,
    },
    "/workspace/examples/hello.py": {
      type: "file",
      updatedAt: t,
      content: 'print("Hola desde DevAurora")\n',
    },
    "/workspace/examples/hello.js": {
      type: "file",
      updatedAt: t,
      content: 'console.log("Hola desde DevAurora");\n',
    },
    "/workspace/examples/hello.c": {
      type: "file",
      updatedAt: t,
      content: `#include <stdio.h>
int main(void) {
    printf("Hola desde DevAurora\\n");
    return 0;
}
`,
    },
    "/workspace/src/main.ts": {
      type: "file",
      updatedAt: t,
      content: `function greet(name: string): string {
  return \`Hola, \${name}\`;
}

console.log(greet("DevAurora"));
`,
    },
  };
  return files;
}

export function ensureDir(map: VfsMap, path: string): VfsMap {
  const n = normalizePath(path);
  const next = { ...map };
  const parts = n.split("/").filter(Boolean);
  let acc = "";
  for (const part of parts) {
    acc += "/" + part;
    const existing = next[acc];
    if (!existing) {
      next[acc] = { type: "dir", updatedAt: now() };
    } else if (existing.type !== "dir") {
      throw new Error(`mkdir: ${acc}: Not a directory`);
    }
  }
  if (!next["/"]) next["/"] = { type: "dir", updatedAt: now() };
  return next;
}

export function writeFile(map: VfsMap, path: string, content: string): VfsMap {
  const n = normalizePath(path);
  if (n === "/") throw new Error("No se puede escribir en /");
  const parent = parentPath(n);
  let next = ensureDir(map, parent);
  const existing = next[n];
  if (existing?.type === "dir") throw new Error(`${n}: Is a directory`);
  next = { ...next, [n]: { type: "file", content, updatedAt: now() } };
  return next;
}

export function readFile(map: VfsMap, path: string): string {
  const n = normalizePath(path);
  const entry = map[n];
  if (!entry) throw new Error(`${n}: No such file or directory`);
  if (entry.type !== "file") throw new Error(`${n}: Is a directory`);
  return entry.content ?? "";
}

export function exists(map: VfsMap, path: string): boolean {
  return Boolean(map[normalizePath(path)]);
}

export function isDir(map: VfsMap, path: string): boolean {
  return map[normalizePath(path)]?.type === "dir";
}

export function isFile(map: VfsMap, path: string): boolean {
  return map[normalizePath(path)]?.type === "file";
}

export function listDir(map: VfsMap, path: string): string[] {
  const n = normalizePath(path);
  const entry = map[n];
  if (!entry) throw new Error(`${n}: No such file or directory`);
  if (entry.type !== "dir") throw new Error(`${n}: Not a directory`);
  const prefix = n === "/" ? "/" : n + "/";
  const names = new Set<string>();
  for (const key of Object.keys(map)) {
    if (key === n) continue;
    if (!key.startsWith(prefix)) continue;
    const rest = key.slice(prefix.length);
    const name = rest.split("/")[0];
    if (name) names.add(name);
  }
  return [...names].sort();
}

export function removePath(map: VfsMap, path: string, recursive = false): VfsMap {
  const n = normalizePath(path);
  if (n === "/" || n === WORKSPACE) {
    throw new Error(`rm: cannot remove '${n}'`);
  }
  const entry = map[n];
  if (!entry) throw new Error(`rm: ${n}: No such file or directory`);
  const next = { ...map };
  if (entry.type === "dir") {
    const prefix = n + "/";
    const children = Object.keys(next).filter((k) => k === n || k.startsWith(prefix));
    if (children.length > 1 && !recursive) {
      throw new Error(`rm: ${n}: Directory not empty`);
    }
    for (const k of children) delete next[k];
  } else {
    delete next[n];
  }
  return next;
}

export function copyPath(map: VfsMap, from: string, to: string): VfsMap {
  const src = normalizePath(from);
  const dst = normalizePath(to);
  const entry = map[src];
  if (!entry) throw new Error(`cp: ${src}: No such file or directory`);
  if (entry.type === "dir") throw new Error("cp: omitiendo directorio (usa archivos)");
  return writeFile(map, dst, entry.content ?? "");
}

export function movePath(map: VfsMap, from: string, to: string): VfsMap {
  const copied = copyPath(map, from, to);
  return removePath(copied, from, true);
}

export function tree(map: VfsMap, path: string, depth = 4): string {
  const n = normalizePath(path);
  const lines: string[] = [baseName(n) === "/" ? "/" : baseName(n)];
  const walk = (dir: string, prefix: string, level: number) => {
    if (level > depth) return;
    const names = listDir(map, dir);
    names.forEach((name, i) => {
      const last = i === names.length - 1;
      const child = joinPath(dir, name);
      const branch = last ? "└── " : "├── ";
      const nextPrefix = prefix + (last ? "    " : "│   ");
      const dirMark = isDir(map, child) ? "/" : "";
      lines.push(prefix + branch + name + dirMark);
      if (isDir(map, child)) walk(child, nextPrefix, level + 1);
    });
  };
  if (isDir(map, n)) walk(n, "", 1);
  return lines.join("\n");
}

export function allFiles(map: VfsMap): string[] {
  return Object.keys(map)
    .filter((k) => map[k]?.type === "file")
    .sort();
}

export function formatListing(
  map: VfsMap,
  path: string,
  all = false,
  long = false,
): string {
  const names = listDir(map, path);
  const shown = all ? [".", "..", ...names] : names.filter((n) => !n.startsWith("."));
  if (!long) return shown.join("  ");
  const lines = shown.map((name) => {
    if (name === "." || name === "..") {
      return `drwxr-xr-x  ${name}`;
    }
    const child = joinPath(path, name);
    const entry = map[child];
    const stamp = entry
      ? new Date(entry.updatedAt).toISOString().slice(0, 16).replace("T", " ")
      : "";
    if (entry?.type === "dir") return `drwxr-xr-x  ${stamp}  ${name}/`;
    const size = (entry?.content ?? "").length.toString().padStart(6, " ");
    return `-rw-r--r--  ${stamp}  ${size}  ${name}`;
  });
  return lines.join("\n");
}
