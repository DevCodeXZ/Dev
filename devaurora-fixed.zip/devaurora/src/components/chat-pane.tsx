import { useEffect, useRef, useState } from "react";
import { ChevronRight, Terminal as TerminalIcon } from "lucide-react";
import { Markdown } from "./markdown";
import { Composer } from "./composer";
import { useChat } from "@/lib/use-chat";
import { useAppStore } from "@/lib/store";
import type { ChatMessage } from "@/lib/types";
import { cn } from "@/lib/cn";

const SUGGESTIONS = [
  { title: "Servidor Express", prompt: "Crea un servidor Express en /workspace/src/server.js con una ruta GET /salud que devuelva JSON, y ejecútalo para verificar la sintaxis con node --check." },
  { title: "Hola mundo en Rust", prompt: "Escribe un hola mundo en Rust en /workspace/src/main.rs y compílalo/ejecútalo desde la terminal." },
  { title: "Script de Python", prompt: "Crea /workspace/src/fizzbuzz.py que imprima FizzBuzz del 1 al 30 y ejecútalo." },
  { title: "Explica un algoritmo", prompt: "Explícame quicksort con un ejemplo en Python y luego ejecuta el ejemplo." },
];

function ToolCard({ name, status, detail }: { name: string; status: "running" | "done"; detail: string }) {
  const label =
    name === "run_terminal"
      ? "Terminal"
      : name === "write_file"
        ? "Escribir archivo"
        : name === "read_file"
          ? "Leer archivo"
          : name === "execute_code"
            ? "Ejecutar código"
            : name;
  return (
    <div className="my-2 rounded-xl border border-border bg-elevated px-3 py-2 text-sm">
      <div className="flex items-center gap-2 font-medium">
        <TerminalIcon className="size-3.5 text-muted" />
        {status === "running" ? `Usando ${label}…` : label}
      </div>
      {detail ? <pre className="mt-1 max-h-24 overflow-auto font-mono text-[11px] text-dim">{detail}</pre> : null}
    </div>
  );
}

function Reasoning({ text, openDefault }: { text: string; openDefault?: boolean }) {
  const [open, setOpen] = useState(Boolean(openDefault));
  if (!text) return null;
  return (
    <div className="mb-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg"
      >
        <ChevronRight className={cn("size-4 transition-transform", open && "rotate-90")} />
        Pensando
      </button>
      {open && (
        <div className="mt-1 whitespace-pre-wrap border-l border-border pl-3 text-sm text-dim">{text}</div>
      )}
    </div>
  );
}

function MessageView({ message }: { message: ChatMessage }) {
  if (message.role === "tool") return null;
  if (message.role === "assistant" && message.toolCalls?.length && !message.content) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4">
        {message.toolCalls.map((t) => (
          <ToolCard key={t.id} name={t.name} status="done" detail={t.arguments.slice(0, 160)} />
        ))}
      </div>
    );
  }
  if (message.role === "user") {
    return (
      <div className="mx-auto flex w-full max-w-3xl justify-end px-4">
        <div className="max-w-[85%] rounded-3xl bg-user px-4 py-2.5 text-[15px] leading-6 whitespace-pre-wrap">
          {message.content}
          {message.attachments?.length ? (
            <div className="mt-2 flex flex-wrap gap-1">
              {message.attachments.map((a) => (
                <span key={a.path} className="rounded-full bg-elevated px-2 py-0.5 text-xs text-muted">
                  {a.name}
                </span>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    );
  }
  // assistant message — sin avatar/logo
  return (
    <div className="mx-auto w-full max-w-3xl px-4">
      <div className="min-w-0">
        {message.reasoning ? <Reasoning text={message.reasoning} /> : null}
        {message.content ? <Markdown text={message.content} /> : null}
      </div>
    </div>
  );
}

export function ChatPane() {
  const { streaming, live, send, stop } = useChat();
  const chats = useAppStore((s) => s.chats);
  const activeChatId = useAppStore((s) => s.activeChatId);
  const chat = chats.find((c) => c.id === activeChatId);
  const messages = chat?.messages ?? [];
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "end" });
  }, [messages.length, live?.content, live?.reasoning]);

  const empty = messages.length === 0 && !live;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div
        className="min-h-0 flex-1 overflow-y-auto"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
        }}
      >
        {empty ? (
          <div className="flex h-full flex-col items-center justify-center px-4">
            <h1 className="mt-5 text-center text-2xl font-semibold tracking-tight text-balance md:text-3xl">
              ¿En qué estás pensando?
            </h1>
            <div className="mt-8 grid w-full max-w-2xl grid-cols-1 gap-2 sm:grid-cols-2">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s.title}
                  type="button"
                  onClick={() => void send(s.prompt)}
                  className="rounded-2xl border border-border bg-transparent px-4 py-3 text-left hover:bg-hover"
                >
                  <div className="text-sm font-medium">{s.title}</div>
                  <div className="mt-0.5 line-clamp-2 text-xs text-dim">{s.prompt}</div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-6 py-6">
            {messages.map((m) => (
              <MessageView key={m.id} message={m} />
            ))}
            {live && (
              <div className="mx-auto w-full max-w-3xl px-4">
                <div className="min-w-0">
                  {live.reasoning && !live.content ? (
                    <div className="da-thinking text-sm font-medium">Pensando</div>
                  ) : live.reasoning ? (
                    <Reasoning text={live.reasoning} />
                  ) : null}
                  {live.tools.map((t, i) => (
                    <ToolCard key={i} name={t.name} status={t.status} detail={t.detail} />
                  ))}
                  {live.content ? (
                    <Markdown text={live.content} />
                  ) : !live.tools.length && !live.reasoning ? (
                    <div className="flex gap-1 pt-2">
                      <span className="da-dot size-1.5 rounded-full bg-fg" />
                      <span className="da-dot size-1.5 rounded-full bg-fg" />
                      <span className="da-dot size-1.5 rounded-full bg-fg" />
                    </div>
                  ) : null}
                </div>
              </div>
            )}
            <div ref={bottom} />
          </div>
        )}
      </div>
      <Composer onSend={(t, a) => void send(t, a)} streaming={streaming} onStop={stop} />
    </div>
  );
}
