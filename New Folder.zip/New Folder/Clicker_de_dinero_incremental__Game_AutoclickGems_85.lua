-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.InterfaceScript.AutoclickGems
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v1 = game.ReplicatedStorage.Events.Upgrade.GemUpgrade
wait(2)
local v2 = game:GetService("Players").LocalPlayer:WaitForChild("Stats")
while true do
	if v2.ResearchUpgrade12.Value ~= 0 and v2.GemUpgradeAutomation.Value == 0 then
		for v3 = 1, v2.ResearchUpgrade12.Value do
			v1:FireServer(v3, false, true)
		end
	end
	wait(1)
end