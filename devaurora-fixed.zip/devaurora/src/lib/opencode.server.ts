/** Server-only OpenCode Zen credentials. Never import from client modules. */

export const OPENCODE_BASE = "https://opencode.ai/zen/v1";

export function getOpenCodeKey(): string {
  return (
    process.env.OPENCODE_API_KEY ||
    "sk-9wcySbWQ7XMY3lgxDknfl1npw8oyyDjiVLqWQvRIII4VUcHxnH5KEMWBV3UAS6hy"
  );
}
