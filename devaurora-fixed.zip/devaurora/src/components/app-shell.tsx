import { useEffect, useState } from "react";
import { Group, Panel, Separator } from "react-resizable-panels";
import {
  Folder,
  Moon,
  PanelLeft,
  Settings,
  SquarePen,
  Sun,
  Terminal,
  Trash2,
  X,
} from "lucide-react";
import { ChatPane } from "./chat-pane";
import { ModelMenu } from "./model-menu";
import { Sidebar } from "./sidebar";
import { TerminalPane } from "./terminal-pane";
import { WorkspacePane } from "./workspace-pane";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/lib/store";

function useIsMobile() {
  const [mobile, setMobile] = useState(false);
  useEffect(() => {
    const q = window.matchMedia("(max-width: 767px)");
    const fn = () => setMobile(q.matches);
    fn();
    q.addEventListener("change", fn);
    return () => q.removeEventListener("change", fn);
  }, []);
  return mobile;
}

function SettingsMenu({ onClose }: { onClose: () => void }) {
  const theme = useAppStore((s) => s.theme);
  const setTheme = useAppStore((s) => s.setTheme);
  const clearChats = useAppStore((s) => s.clearChats);
  const resetWorkspace = useAppStore((s) => s.resetWorkspace);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <button type="button" className="absolute inset-0 bg-overlay" aria-label="Cerrar" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-2xl border border-border bg-elevated p-5 shadow-xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-semibold">Ajustes</h2>
          <button
            type="button"
            className="flex size-9 items-center justify-center rounded-lg hover:bg-hover"
            onClick={onClose}
            aria-label="Cerrar"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-sm">Tema</span>
          <button
            type="button"
            className="inline-flex h-10 items-center gap-2 rounded-lg bg-chip px-3 text-sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            {theme === "dark" ? "Oscuro" : "Claro"}
          </button>
        </div>
        <button
          type="button"
          className="mt-2 flex h-11 w-full items-center gap-2 rounded-lg px-2 text-sm hover:bg-hover"
          onClick={() => {
            clearChats();
            onClose();
          }}
        >
          <Trash2 className="size-4" />
          Borrar todos los chats
        </button>
        <button
          type="button"
          className="flex h-11 w-full items-center gap-2 rounded-lg px-2 text-sm hover:bg-hover"
          onClick={() => {
            resetWorkspace();
            onClose();
          }}
        >
          <Folder className="size-4" />
          Restaurar workspace
        </button>
        <p className="mt-4 text-xs text-dim">
          DevAurora Code usa modelos gratis de OpenCode Zen. El código se ejecuta en un sandbox remoto.
        </p>
      </div>
    </div>
  );
}

export function AppShell() {
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const terminalOpen = useAppStore((s) => s.terminalOpen);
  const workspaceOpen = useAppStore((s) => s.workspaceOpen);
  const setTerminalOpen = useAppStore((s) => s.setTerminalOpen);
  const setWorkspaceOpen = useAppStore((s) => s.setWorkspaceOpen);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const newChat = useAppStore((s) => s.newChat);
  const theme = useAppStore((s) => s.theme);
  const mobile = useIsMobile();
  const [settings, setSettings] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "`") {
        e.preventDefault();
        setTerminalOpen(!useAppStore.getState().terminalOpen);
      }
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === "o") {
        e.preventDefault();
        newChat();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [newChat, setTerminalOpen]);

  const collapsed = !sidebarOpen;

  return (
    <div className="flex h-dvh overflow-hidden bg-main text-fg">
      {mobileNav && (
        <button
          type="button"
          className="fixed inset-0 z-30 bg-overlay md:hidden"
          aria-label="Cerrar menú"
          onClick={() => setMobileNav(false)}
        />
      )}
      <div
        className={cn(
          "shrink-0",
          "max-md:fixed max-md:inset-y-0 max-md:left-0 max-md:z-40",
          !mobileNav && "max-md:hidden",
        )}
      >
        <Sidebar
          collapsed={collapsed}
          mobile={mobileNav}
          onClose={() => setMobileNav(false)}
        />
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-1 px-2">
          <button
            type="button"
            className={cn(
              "flex size-11 items-center justify-center rounded-lg hover:bg-hover",
              !collapsed && "md:hidden",
            )}
            onClick={() => {
              if (window.matchMedia("(max-width: 767px)").matches) setMobileNav(true);
              else toggleSidebar();
            }}
            aria-label="Abrir menú"
          >
            <PanelLeft className="size-5" />
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-lg hover:bg-hover md:hidden"
            onClick={() => newChat()}
            aria-label="Nuevo chat"
          >
            <SquarePen className="size-5" />
          </button>
          <div className="flex flex-1 justify-center">
            <ModelMenu />
          </div>
          <button
            type="button"
            className={cn(
              "flex size-11 items-center justify-center rounded-lg hover:bg-hover",
              terminalOpen && "text-accent",
            )}
            onClick={() => setTerminalOpen(!terminalOpen)}
            aria-label="Terminal"
            title="Terminal (Ctrl+`)"
          >
            <Terminal className="size-5" />
          </button>
          <button
            type="button"
            className={cn(
              "flex size-11 items-center justify-center rounded-lg hover:bg-hover",
              workspaceOpen && "text-accent",
            )}
            onClick={() => setWorkspaceOpen(!workspaceOpen)}
            aria-label="Archivos"
          >
            <Folder className="size-5" />
          </button>
          <button
            type="button"
            className="flex size-11 items-center justify-center rounded-lg hover:bg-hover"
            onClick={() => setSettings(true)}
            aria-label="Ajustes"
          >
            <Settings className="size-5" />
          </button>
        </header>

        <div className="min-h-0 flex-1">
          {mobile ? (
            <div className="relative h-full">
              <ChatPane />
              {workspaceOpen && (
                <div className="absolute inset-0 z-20 bg-main">
                  <WorkspacePane onClose={() => setWorkspaceOpen(false)} />
                </div>
              )}
              {terminalOpen && (
                <div className="absolute inset-x-0 bottom-0 z-20 h-[70%] overflow-hidden rounded-t-2xl border-t border-border shadow-xl">
                  <TerminalPane onClose={() => setTerminalOpen(false)} />
                </div>
              )}
            </div>
          ) : (
            <Group orientation="vertical" className="h-full">
              <Panel minSize="30" defaultSize={terminalOpen ? "68" : "100"} className="overflow-hidden">
                {workspaceOpen ? (
                  <Group orientation="horizontal" className="h-full">
                    <Panel minSize="35" defaultSize="58" className="overflow-hidden">
                      <ChatPane />
                    </Panel>
                    <Separator className="w-1 bg-border hover:bg-accent" />
                    <Panel minSize="25" defaultSize="42" className="overflow-hidden">
                      <WorkspacePane onClose={() => setWorkspaceOpen(false)} />
                    </Panel>
                  </Group>
                ) : (
                  <ChatPane />
                )}
              </Panel>
              {terminalOpen && (
                <>
                  <Separator className="h-1 bg-border hover:bg-accent" />
                  <Panel minSize="18" defaultSize="32" collapsible className="overflow-hidden">
                    <TerminalPane onClose={() => setTerminalOpen(false)} />
                  </Panel>
                </>
              )}
            </Group>
          )}
        </div>
      </div>
      {settings && <SettingsMenu onClose={() => setSettings(false)} />}
    </div>
  );
}
