-- ========================================
-- Path: Players.VioletaPurpleX.PlayerGui.GameUi.GameBackground.GameMenu5.Button1.BE3
-- Class: LocalScript
-- PlaceId: 18408132742
-- Place: Clicker_de_dinero_incremental_
-- ========================================
local v_u_1 = game.ReplicatedStorage.CEvents.PlaySound
local v_u_2 = script.Parent.Size
local v_u_3 = script.Parent.Position
local v_u_4, v_u_5
if script.Parent:FindFirstChild("ImageLabel") then
	v_u_4 = script.Parent.ImageLabel.Size
	v_u_5 = script.Parent.ImageLabel.Position
else
	v_u_4 = nil
	v_u_5 = nil
end
script.Parent.Button.MouseEnter:Connect(function()
	-- upvalues: (copy) v_u_3, (ref) v_u_4, (ref) v_u_5
	local v6 = script.Parent
	v6.ZIndex = v6.ZIndex + 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = true
	end
	script.Parent:TweenPosition(UDim2.new(v_u_3.X.Scale + 0.15, 0, v_u_3.Y.Scale, 0), "In", "Linear", 0.1, true)
	if script.Parent:FindFirstChild("ImageLabel") then
		script.Parent.ImageLabel:TweenSize(UDim2.new(v_u_4.X.Scale * 1.2, 0, v_u_4.Y.Scale * 1.2, 0), "In", "Linear", 0.075, true)
		script.Parent.ImageLabel:TweenPosition(UDim2.new(v_u_5.X.Scale, 0, v_u_5.Y.Scale - 0.05, 0), "In", "Linear", 0.075, true)
		for _ = 1, 5 do
			local v7 = script.Parent.ImageLabel
			v7.Rotation = v7.Rotation + 2
			task.wait(0.02)
		end
	end
end)
script.Parent.Button.MouseLeave:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (ref) v_u_4, (ref) v_u_5
	local v8 = script.Parent
	v8.ZIndex = v8.ZIndex - 1
	if script.Parent:FindFirstChild("InfoLabel") then
		script.Parent.InfoLabel.Visible = false
	end
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(v_u_2, "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(v_u_3, "In", "Linear", 0.1, true)
	end
	if script.Parent:FindFirstChild("ImageLabel") then
		script.Parent.ImageLabel:TweenSize(v_u_4, "In", "Linear", 0.075, true)
		script.Parent.ImageLabel:TweenPosition(v_u_5, "In", "Linear", 0.075, true)
		for _ = 1, 5 do
			local v9 = script.Parent.ImageLabel
			v9.Rotation = v9.Rotation - 2
			task.wait(0.02)
		end
		script.Parent.ImageLabel.Rotation = 0
	end
end)
script.Parent.Button.MouseButton1Down:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(UDim2.new(v_u_2.X.Scale / 1.1, 0, v_u_2.Y.Scale / 1.1, 0), "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(UDim2.new(v_u_3.X.Scale + 0.15 + v_u_2.X.Scale / 20, 0, v_u_3.Y.Scale + v_u_2.Y.Scale / 20, 0), "In", "Linear", 0.1, true)
	end
end)
script.Parent.Button.MouseButton1Up:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if script.Parent.Name ~= "MaxButton" then
		script.Parent:TweenSize(v_u_2, "In", "Linear", 0.1, true)
		script.Parent:TweenPosition(UDim2.new(v_u_3.X.Scale + 0.15, 0, v_u_3.Y.Scale, 0), "In", "Linear", 0.1, true)
	end
end)
script.Parent.Button.MouseButton1Click:Connect(function()
	-- upvalues: (copy) v_u_1
	v_u_1:Fire("Click")
end)