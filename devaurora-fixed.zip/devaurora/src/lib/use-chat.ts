import { useCallback, useRef, useState } from "react";
import { executeSnippet, runCommand } from "./shell";
import { uid, useAppStore, workspaceSummary } from "./store";
import type { ApiChatMessage, ChatMessage, ToolCall } from "./types";
import { normalizePath, readFile, resolvePath, writeFile } from "./vfs";

type Live = {
  content: string;
  reasoning: string;
  tools: { name: string; status: "running" | "done"; detail: string }[];
};

function toApi(messages: ChatMessage[]): ApiChatMessage[] {
  return messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role,
      content: m.content,
      toolCalls: m.toolCalls,
      toolCallId: m.toolCallId,
    }));
}

async function dispatchTool(call: ToolCall): Promise<string> {
  const store = useAppStore.getState();
  let args: Record<string, unknown> = {};
  try {
    args = JSON.parse(call.arguments || "{}") as Record<string, unknown>;
  } catch {
    return "Argumentos inválidos";
  }

  if (call.name === "run_terminal") {
    const command = String(args.command ?? "");
    store.setTerminalOpen(true);
    store.pushTerminal({ kind: "in", text: `$ ${command}` });
    const result = await runCommand(command);
    if (result.clear) store.clearTerminal();
    if (result.output) store.pushTerminal({ kind: "out", text: result.output });
    if (result.closeTerminal) store.setTerminalOpen(false);
    if (result.openWorkspace) store.setWorkspaceOpen(true);
    return result.output || "(sin salida)";
  }

  if (call.name === "write_file") {
    const path = resolvePath(store.cwd, String(args.path ?? ""));
    const content = String(args.content ?? "");
    store.setVfs(writeFile(store.vfs, path, content));
    store.setTerminalOpen(true);
    store.pushTerminal({ kind: "sys", text: `wrote ${path} (${content.length} bytes)` });
    store.setOpenFilePath(path);
    return `Archivo escrito: ${path}`;
  }

  if (call.name === "read_file") {
    const path = resolvePath(store.cwd, String(args.path ?? ""));
    try {
      const content = readFile(store.vfs, normalizePath(path));
      return content.length > 40_000 ? content.slice(0, 40_000) + "\n…[truncado]" : content;
    } catch (e) {
      return e instanceof Error ? e.message : "No se pudo leer";
    }
  }

  if (call.name === "execute_code") {
    const language = String(args.language ?? "python");
    const code = String(args.code ?? "");
    store.setTerminalOpen(true);
    store.pushTerminal({ kind: "in", text: `$ run ${language}` });
    const out = await executeSnippet(language, code, String(args.stdin ?? ""));
    store.pushTerminal({ kind: "out", text: out || "(sin salida)" });
    return out || "(sin salida)";
  }

  return `Herramienta desconocida: ${call.name}`;
}

async function consumeStream(
  res: Response,
  onContent: (t: string) => void,
  onReasoning: (t: string) => void,
): Promise<{ content: string; reasoning: string; toolCalls: ToolCall[]; error?: string }> {
  if (!res.body) return { content: "", reasoning: "", toolCalls: [], error: "Sin respuesta" };
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let content = "";
  let reasoning = "";
  let toolCalls: ToolCall[] = [];
  let error: string | undefined;

  const handle = (line: string) => {
    const trimmed = line.trim();
    if (!trimmed.startsWith("data:")) return;
    const data = trimmed.slice(5).trim();
    if (!data) return;
    let json: {
      type?: string;
      text?: string;
      error?: string;
      tool_calls?: ToolCall[];
    };
    try {
      json = JSON.parse(data) as typeof json;
    } catch {
      return;
    }
    if (json.type === "content" && json.text) {
      content += json.text;
      onContent(json.text);
    } else if (json.type === "reasoning" && json.text) {
      reasoning += json.text;
      onReasoning(json.text);
    } else if (json.type === "tool_calls" && json.tool_calls) {
      toolCalls = json.tool_calls;
    } else if (json.type === "error") {
      error = json.error ?? "Error";
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";
    for (const line of lines) handle(line);
  }
  if (buffer.trim()) handle(buffer);
  return { content, reasoning, toolCalls, error };
}

export function useChat() {
  const [streaming, setStreaming] = useState(false);
  const [live, setLive] = useState<Live | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const liveRef = useRef<Live | null>(null);

  const stop = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setStreaming(false);
  }, []);

  const send = useCallback(async (text: string, attachments?: { name: string; path: string }[]) => {
    const trimmed = text.trim();
    if (!trimmed && !attachments?.length) return;
    const store = useAppStore.getState();
    let chatId = store.activeChatId;
    if (!chatId) chatId = store.newChat();
    const chat = useAppStore.getState().chats.find((c) => c.id === chatId);
    if (!chat) return;

    const userMsg: ChatMessage = {
      id: uid(),
      role: "user",
      content: trimmed,
      attachments,
      createdAt: Date.now(),
    };
    let messages: ChatMessage[] = [...chat.messages, userMsg];
    store.commitMessages(chatId, messages);

    setStreaming(true);
    const initialLive: Live = { content: "", reasoning: "", tools: [] };
    liveRef.current = initialLive;
    setLive(initialLive);
    const ac = new AbortController();
    abortRef.current = ac;

    try {
      for (let step = 0; step < 8; step++) {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: ac.signal,
          body: JSON.stringify({
            model: useAppStore.getState().modelId,
            messages: toApi(messages),
            workspace: workspaceSummary(),
          }),
        });
        if (!res.ok) {
          const err = await res.text();
          throw new Error(err.slice(0, 300) || `HTTP ${res.status}`);
        }
        const result = await consumeStream(
          res,
          (t) => setLive((prev) => {
            const next = { ...(prev ?? { content: "", reasoning: "", tools: [] }), content: (prev?.content ?? "") + t };
            liveRef.current = next;
            return next;
          }),
          (t) => setLive((prev) => {
            const next = { ...(prev ?? { content: "", reasoning: "", tools: [] }), reasoning: (prev?.reasoning ?? "") + t };
            liveRef.current = next;
            return next;
          }),
        );
        if (result.error) throw new Error(result.error);

        if (result.toolCalls.length) {
          const assistantTool: ChatMessage = {
            id: uid(),
            role: "assistant",
            content: result.content,
            reasoning: result.reasoning || undefined,
            toolCalls: result.toolCalls,
            createdAt: Date.now(),
          };
          messages = [...messages, assistantTool];
          for (const call of result.toolCalls) {
            setLive((prev) => ({
              content: prev?.content ?? result.content,
              reasoning: prev?.reasoning ?? result.reasoning,
              tools: [
                ...(prev?.tools ?? []),
                { name: call.name, status: "running", detail: call.arguments.slice(0, 120) },
              ],
            }));
            const output = await dispatchTool(call);
            messages = [
              ...messages,
              {
                id: uid(),
                role: "tool",
                content: output,
                toolCallId: call.id,
                createdAt: Date.now(),
              },
            ];
            setLive((prev) => ({
              content: prev?.content ?? "",
              reasoning: prev?.reasoning ?? "",
              tools: (prev?.tools ?? []).map((t) =>
                t.name === call.name && t.status === "running"
                  ? { ...t, status: "done", detail: output.slice(0, 160) }
                  : t,
              ),
            }));
          }
          store.commitMessages(chatId, messages);
          continue;
        }

        const assistant: ChatMessage = {
          id: uid(),
          role: "assistant",
          content: result.content,
          reasoning: result.reasoning || undefined,
          createdAt: Date.now(),
        };
        messages = [...messages, assistant];
        store.commitMessages(chatId, messages);
        break;
      }
    } catch (e) {
      if ((e as Error).name === "AbortError") {
        const partial = liveRefContent();
        if (partial) {
          messages = [
            ...messages,
            {
              id: uid(),
              role: "assistant",
              content: partial,
              createdAt: Date.now(),
            },
          ];
          store.commitMessages(chatId, messages);
        }
      } else {
        messages = [
          ...messages,
          {
            id: uid(),
            role: "assistant",
            content: `No se pudo completar la respuesta: ${e instanceof Error ? e.message : "error"}`,
            createdAt: Date.now(),
          },
        ];
        store.commitMessages(chatId, messages);
      }
    } finally {
      abortRef.current = null;
      setStreaming(false);
      setLive(null);
    }

    function liveRefContent(): string {
      return liveRef.current?.content ?? "";
    }
  }, []);

  return { streaming, live, send, stop };
}

export type { Live };
