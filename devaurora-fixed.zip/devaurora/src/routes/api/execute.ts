import { createFileRoute } from "@tanstack/react-router";
import { executeOnPiston } from "@/lib/piston.server";

export const Route = createFileRoute("/api/execute")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = (await request.json()) as {
            language?: string;
            files?: { name: string; content: string }[];
            stdin?: string;
            args?: string[];
          };
          const language = (body.language ?? "").trim();
          if (!language) {
            return Response.json({ ok: false, error: "Falta el lenguaje" }, { status: 400 });
          }
          const files = Array.isArray(body.files) ? body.files.slice(0, 30) : [];
          if (!files.length) {
            return Response.json({ ok: false, error: "No hay código para ejecutar" }, { status: 400 });
          }
          for (const f of files) {
            if (typeof f.content !== "string") {
              return Response.json({ ok: false, error: "Archivo inválido" }, { status: 400 });
            }
            if (f.content.length > 200_000) {
              return Response.json({ ok: false, error: "Archivo demasiado grande" }, { status: 400 });
            }
          }
          const result = await executeOnPiston({
            language,
            files,
            stdin: typeof body.stdin === "string" ? body.stdin.slice(0, 20_000) : "",
            args: Array.isArray(body.args)
              ? body.args.map(String).slice(0, 20)
              : [],
          });
          return Response.json(result);
        } catch (err) {
          return Response.json(
            {
              ok: false,
              error: err instanceof Error ? err.message : "Error al ejecutar",
            },
            { status: 500 },
          );
        }
      },
    },
  },
});
