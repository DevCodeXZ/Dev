export type ModelInfo = {
  id: string;
  name: string;
  tag: string;
  description: string;
};

export const MODELS: ModelInfo[] = [
  {
    id: "big-pickle",
    name: "DevAurora",
    tag: "Gratis · Recomendado",
    description: "Modelo principal. Mejor para programar, usar terminal y razonar.",
  },
];

export const DEFAULT_MODEL_ID = "big-pickle";

export function getModel(id: string): ModelInfo {
  return MODELS.find((m) => m.id === id) ?? MODELS[0];
}
