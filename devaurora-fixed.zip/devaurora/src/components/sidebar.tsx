import { useMemo, useState, type ReactNode } from "react";
import {
  Folder,
  MoreHorizontal,
  PanelLeft,
  Pencil,
  Search,
  SquarePen,
  Terminal,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { useAppStore } from "@/lib/store";
import { Logo } from "./logo";

function groupLabel(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = start(now) - start(d);
  if (diff === 0) return "Hoy";
  if (diff === 86400000) return "Ayer";
  if (diff < 7 * 86400000) return "Últimos 7 días";
  if (diff < 30 * 86400000) return "Últimos 30 días";
  return "Anteriores";
}

export function Sidebar({
  collapsed,
  mobile,
  onClose,
}: {
  collapsed: boolean;
  mobile: boolean;
  onClose: () => void;
}) {
  const chats = useAppStore((s) => s.chats);
  const activeChatId = useAppStore((s) => s.activeChatId);
  const newChat = useAppStore((s) => s.newChat);
  const setActiveChat = useAppStore((s) => s.setActiveChat);
  const deleteChat = useAppStore((s) => s.deleteChat);
  const renameChat = useAppStore((s) => s.renameChat);
  const setTerminalOpen = useAppStore((s) => s.setTerminalOpen);
  const setWorkspaceOpen = useAppStore((s) => s.setWorkspaceOpen);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [menuId, setMenuId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? chats.filter((c) => c.title.toLowerCase().includes(q) || c.messages.some((m) => m.content.toLowerCase().includes(q)))
      : chats;
    const groups: { label: string; items: typeof list }[] = [];
    for (const chat of list) {
      const label = groupLabel(chat.updatedAt);
      const g = groups.find((x) => x.label === label);
      if (g) g.items.push(chat);
      else groups.push({ label, items: [chat] });
    }
    return groups;
  }, [chats, query]);

  const width = collapsed && !mobile ? "w-[52px]" : "w-[260px]";

  return (
    <aside
      className={cn(
        "flex h-full shrink-0 flex-col bg-sidebar text-fg transition-[width] duration-200",
        width,
        mobile && "w-[260px]",
      )}
    >
      <div className="flex h-14 items-center gap-2 px-2">
        <button
          type="button"
          className="flex size-10 items-center justify-center rounded-lg hover:bg-hover"
          onClick={() => (mobile ? onClose() : toggleSidebar())}
          aria-label="Barra lateral"
        >
          {collapsed && !mobile ? <Logo size={28} /> : <PanelLeft className="size-5 text-muted" />}
        </button>
        {(!collapsed || mobile) && (
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <Logo size={22} />
            <span className="truncate text-sm font-semibold tracking-tight">DevAurora Code</span>
          </div>
        )}
      </div>

      <div className="flex flex-col gap-1 px-2">
        <IconBtn
          collapsed={collapsed && !mobile}
          icon={<SquarePen className="size-4" />}
          label="Nuevo chat"
          onClick={() => {
            newChat();
            if (mobile) onClose();
          }}
        />
        <IconBtn
          collapsed={collapsed && !mobile}
          icon={<Search className="size-4" />}
          label="Buscar chats"
          onClick={() => {
            if (collapsed && !mobile) toggleSidebar();
            setSearching(true);
          }}
        />
        <IconBtn
          collapsed={collapsed && !mobile}
          icon={<Terminal className="size-4" />}
          label="Terminal"
          onClick={() => {
            setTerminalOpen(true);
            if (mobile) onClose();
          }}
        />
        <IconBtn
          collapsed={collapsed && !mobile}
          icon={<Folder className="size-4" />}
          label="Archivos"
          onClick={() => {
            setWorkspaceOpen(true);
            if (mobile) onClose();
          }}
        />
      </div>

      {(!collapsed || mobile) && (
        <div className="mt-3 min-h-0 flex-1 overflow-y-auto px-2 pb-3">
          {searching && (
            <div className="mb-2 flex items-center gap-1 rounded-lg bg-elevated px-2">
              <Search className="size-3.5 text-dim" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar chats"
                className="h-9 w-full bg-transparent text-sm outline-none placeholder:text-dim"
              />
              <button
                type="button"
                className="size-8 text-dim hover:text-fg"
                onClick={() => {
                  setSearching(false);
                  setQuery("");
                }}
                aria-label="Cerrar búsqueda"
              >
                <X className="size-4" />
              </button>
            </div>
          )}
          {filtered.map((group) => (
            <div key={group.label} className="mb-3">
              <div className="px-2 pb-1 pt-2 text-[11px] font-medium text-dim">{group.label}</div>
              {group.items.map((chat) => (
                <div key={chat.id} className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveChat(chat.id);
                      if (mobile) onClose();
                    }}
                    className={cn(
                      "group flex h-10 w-full items-center rounded-lg px-2 text-left text-sm",
                      chat.id === activeChatId ? "bg-elevated" : "hover:bg-hover",
                    )}
                  >
                    {editingId === chat.id ? (
                      <input
                        autoFocus
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        onBlur={() => {
                          if (draft.trim()) renameChat(chat.id, draft.trim());
                          setEditingId(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                          if (e.key === "Escape") setEditingId(null);
                        }}
                        className="h-8 w-full bg-transparent outline-none"
                      />
                    ) : (
                      <span className="min-w-0 flex-1 truncate">{chat.title}</span>
                    )}
                    <span
                      role="button"
                      tabIndex={0}
                      className="ml-1 hidden size-7 items-center justify-center rounded-md text-dim hover:bg-elevated hover:text-fg group-hover:flex"
                      onClick={(e) => {
                        e.stopPropagation();
                        setMenuId(menuId === chat.id ? null : chat.id);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") setMenuId(chat.id);
                      }}
                    >
                      <MoreHorizontal className="size-4" />
                    </span>
                  </button>
                  {menuId === chat.id && (
                    <div className="absolute right-2 top-10 z-20 w-40 overflow-hidden rounded-xl border border-border bg-elevated py-1 shadow-lg">
                      <button
                        type="button"
                        className="flex h-9 w-full items-center gap-2 px-3 text-sm hover:bg-hover"
                        onClick={() => {
                          setDraft(chat.title);
                          setEditingId(chat.id);
                          setMenuId(null);
                        }}
                      >
                        <Pencil className="size-3.5" />
                        Renombrar
                      </button>
                      <button
                        type="button"
                        className="flex h-9 w-full items-center gap-2 px-3 text-sm text-danger hover:bg-hover"
                        onClick={() => {
                          deleteChat(chat.id);
                          setMenuId(null);
                        }}
                      >
                        <Trash2 className="size-3.5" />
                        Eliminar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {(!collapsed || mobile) && (
        <div className="border-t border-border px-3 py-3">
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-fg">
              D
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-medium">DevAurora</div>
              <div className="truncate text-xs text-dim">Espacio de código</div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}

function IconBtn({
  collapsed,
  icon,
  label,
  onClick,
}: {
  collapsed: boolean;
  icon: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      className={cn(
        "flex h-11 items-center gap-2 rounded-lg px-2 text-sm hover:bg-hover",
        collapsed && "justify-center",
      )}
    >
      <span className="flex size-7 items-center justify-center text-fg">{icon}</span>
      {!collapsed && <span>{label}</span>}
    </button>
  );
}
